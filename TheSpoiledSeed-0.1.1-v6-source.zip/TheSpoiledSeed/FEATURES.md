# THE SPOILED SEED 0.1.1-v6 — what is in the mod (checklist)

Every item below is in the source. `/ss help` and the Mod Options screen list the same things in-game.

## The monster (The Null)
- States: observing, stalking, disturbance, jumpscare, chase, vanishing (fade in / fade out, pure black halo, glowing white eyes).
- Never in front of the camera; prefers forests, hills, dark, with line of sight; cave-aware spawns in tunnels.
- Chase: predicts where you run, stares then bursts, opens doors, hears sprinting/mining, loses you when you sneak.
- **Adapts**: sprint in a chase -> 25% dash + scream · hide high on blocks -> builds black Null Blocks up to you (50% scream / 50% hit and the hunt goes on)
  · gap between two platforms -> it LEAPS across and screams · wall yourself in (cave/house) -> it breaks the wall, STARES 5 s, screams.
- Ends a chase with a hit, a jumpscare or a kill (never lethal at quest stage 0). Staring at it can make it charge.
- Learns from every escape; every in-game day and every hour of play makes it worse.

## Threat types / events (all via `/ss <name>`, no cooldown)
observe · glimpse · stalk · chase · **cavechase** · bed · jumpscare · footsteps · echo · knock · **doorknock** · whisper · sound · cave · window · torchscare ·
mimic (the Null writes in chat) · blackout · sign · torch · door · theft · **trail** (redstone at a cave exit)
- **Door knock**: loud knocks (3 rounds), then 60% it breaks the door (the door drops as an item, loud crash) and charges + jumpscare. If YOU stand outside, it turns, stares and screams.
- **Organised, not random**: no repeats of the last three events; after a big event only calm ones follow.
- Night, your bed/spawn, places where you spend time, threat (ritual items found), days and hours all raise the pressure.
- Cave exit: after a while underground, a line of redstone dust lies ahead of you when you come out.
- Torch broken: 25% scary sound; at night 10 s of darkness (Blindness) then it appears for a second and vanishes.
- Cursed signs (threatening text, personal ones): appear by themselves; breaking one = 85% jumpscare.
- Theft: only from chests YOU placed (80 blocks), more where you live; items are hidden in a chest nearby.

## Multiplayer
- "Null joined the game" (yellow, vanilla style) 1 minute after you join, and **Null appears in the TAB list**; "Null left the game" when it is sealed.
- It picks one player at a time to hunt harder ("I am watching NAME tonight."), talks about the other players, and announces who it killed.

## Story
5 quests, 3 relics, Null Seal, Ancient Altar, final ritual, saved ending. Structures are placed in organised regions (3 Sites, Shrine, Cairn, Ruin per region).

## Interface
- Custom title screen (your design), hover/click sounds, sad menu music, socials screen, Null eyes in the dark forest.
- **Mod Options** (Mods list -> The Spoiled Seed -> Config, key O, or the pause menu): Horror · Behaviour (8 switches) · Fog · Audio & UI · Progress · Controls · Tools.
- **NEW GAME** button (Progress tab, and Tools -> Quest; click twice) = `/ss newgame`: story, threat, play time and learning back to zero.
- Custom key bindings, chase distance HUD, Survivor's Guide book (comes with you and respawns with you).
