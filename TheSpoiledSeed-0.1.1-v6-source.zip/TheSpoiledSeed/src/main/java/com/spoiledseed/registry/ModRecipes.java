package com.spoiledseed.registry;

import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class ModRecipes {
    public static void register() {
        // THE NULL SEAL = Echo Fragment + Corrupted Core + Forgotten Seal (shapeless)
        GameRegistry.addShapelessRecipe(new ItemStack(ModItems.nullSeal), ModItems.relicEcho, ModItems.relicCore, ModItems.relicSeal);
    }
}
