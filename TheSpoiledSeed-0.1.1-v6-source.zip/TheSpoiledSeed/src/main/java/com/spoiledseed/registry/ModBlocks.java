package com.spoiledseed.registry;

import com.spoiledseed.SpoiledSeed;
import com.spoiledseed.block.BlockAltar;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.item.ItemBlock;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class ModBlocks {
    public static Block ancientAltar;
    /** Black block The Null builds to climb to you. Break it with a pickaxe to keep it. */
    public static Block nullBlock;

    public static void register() {
        ancientAltar = new BlockAltar();
        ancientAltar.setRegistryName(SpoiledSeed.MODID, "ancient_altar");
        ancientAltar.setUnlocalizedName("ancient_altar");
        ancientAltar.setCreativeTab(ModTab.TAB);
        GameRegistry.register(ancientAltar);
        ItemBlock ib = new ItemBlock(ancientAltar);
        ib.setRegistryName(ancientAltar.getRegistryName());
        GameRegistry.register(ib);

        nullBlock = new Block(Material.ROCK);
        nullBlock.setRegistryName(SpoiledSeed.MODID, "null_block");
        nullBlock.setUnlocalizedName("null_block");
        nullBlock.setCreativeTab(ModTab.TAB);
        nullBlock.setHardness(1.5F);
        nullBlock.setResistance(10.0F);
        nullBlock.setHarvestLevel("pickaxe", 0);
        nullBlock.setLightLevel(0.12F);                      // a faint glow in the dark
        GameRegistry.register(nullBlock);
        ItemBlock nb = new ItemBlock(nullBlock);
        nb.setRegistryName(nullBlock.getRegistryName());
        GameRegistry.register(nb);
    }
}
