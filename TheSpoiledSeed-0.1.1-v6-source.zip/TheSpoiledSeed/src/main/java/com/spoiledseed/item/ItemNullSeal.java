package com.spoiledseed.item;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;

/** THE NULL SEAL. Not a weapon: it only works at the Ancient Altar (see FinalRitual). */
public class ItemNullSeal extends Item {
    public ItemNullSeal() { this.setMaxStackSize(1); }

    @Override
    public boolean hasEffect(ItemStack stack) { return true; }

    @Override
    public void onUpdate(ItemStack stack, World world, Entity entity, int slot, boolean selected) {
        if (world.isRemote && selected && world.rand.nextInt(4) == 0) {
            world.spawnParticle(EnumParticleTypes.END_ROD,
                    entity.posX + (world.rand.nextDouble() - 0.5D) * 0.8D,
                    entity.posY + 1.0D + world.rand.nextDouble() * 0.6D,
                    entity.posZ + (world.rand.nextDouble() - 0.5D) * 0.8D, 0.0D, 0.01D, 0.0D);
        }
    }

    @Override
    public ActionResult<ItemStack> onItemRightClick(ItemStack stack, World world, EntityPlayer player, EnumHand hand) {
        if (!world.isRemote) {
            player.addChatMessage(new TextComponentString(TextFormatting.GRAY + "" + TextFormatting.ITALIC
                    + "It is not a weapon. It is a door. Take it to an Ancient Altar."));
        }
        return new ActionResult<ItemStack>(EnumActionResult.SUCCESS, stack);
    }
}
