package com.spoiledseed.client;

import com.spoiledseed.SpoiledSeed;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiWorldSelection;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.client.GuiModList;
import org.lwjgl.opengl.GL11;

/**
 * The Spoiled Seed title screen. Layout follows the 1600x900 design: night forest, logo top-right,
 * text buttons on the left (gray, white on hover, with hover/click sounds), credits bottom-left, version bottom-right.
 * Extras: slow fade-in from black, and now and then a pair of white eyes opens in the treeline.
 */
public class GuiSpoiledMenu extends GuiScreen {
    public static final String DISPLAY_VERSION = "0.1.1 v6";

    private static ResourceLocation tex(String name) {
        return new ResourceLocation(SpoiledSeed.MODID, "textures/gui/" + name + ".png");
    }

    private static final ResourceLocation BG = tex("background"), LOGO = tex("logo"), MADE_BY = tex("made_by"), DEV_NOTE = tex("dev_note");

    private static final int PLAY = 0, MULTI = 1, MODS = 2, OPTIONS = 3, SOCIALS = 4, QUIT = 5;
    private static final float[][] EYE_SPOTS = { { 880, 640 }, { 1235, 615 }, { 575, 600 }, { 1490, 560 }, { 330, 470 } };

    /** One clickable text image. Design coordinates (1600x900): native size, scale, centre. */
    private static class Entry {
        final int action, natW, natH;
        final float scale, cx, cy;
        final ResourceLocation idle, hover;
        int x, y, w, h;
        Entry(int action, String name, int natW, int natH, float scale, float cx, float cy) {
            this.action = action; this.natW = natW; this.natH = natH; this.scale = scale; this.cx = cx; this.cy = cy;
            this.idle = tex(name); this.hover = tex(name + "_hover");
        }
    }

    private final List<Entry> entries = new ArrayList<Entry>();
    private final Random rnd = new Random();
    private int hoverIndex = -1;
    private int fadeIn = 0;
    private int eyeCooldown = 300, eyeLife = 0, eyeSpot = 0;

    @Override
    public void initGui() {
        entries.clear();
        float u = this.height / 900F;
        entries.add(new Entry(PLAY, "play", 176, 72, 1.00F, 160, 312));
        entries.add(new Entry(MULTI, "multiplayer", 440, 72, 0.614F, 160, 405));
        entries.add(new Entry(MODS, "mods", 200, 72, 0.60F, 160, 486));
        entries.add(new Entry(OPTIONS, "options", 296, 72, 0.565F, 148, 552));
        entries.add(new Entry(SOCIALS, "socials", 288, 72, 0.58F, 148, 624));
        entries.add(new Entry(QUIT, "quit", 152, 72, 0.64F, 148, 697));
        for (Entry e : entries) {
            e.w = Math.round(e.natW * e.scale * u);
            e.h = Math.round(e.natH * e.scale * u);
            e.x = Math.round(e.cx * u - e.w / 2F);
            e.y = Math.round(e.cy * u - e.h / 2F);
        }
    }

    @Override
    public void updateScreen() {
        if (fadeIn < 40) fadeIn++;
        if (eyeLife > 0) eyeLife--;
        else if (--eyeCooldown <= 0) {
            eyeLife = 70;
            eyeSpot = rnd.nextInt(EYE_SPOTS.length);
            eyeCooldown = 400 + rnd.nextInt(700);
        }
    }

    private void draw(ResourceLocation loc, int x, int y, int w, int h, int natW, int natH) {
        this.mc.getTextureManager().bindTexture(loc);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
        Gui.drawScaledCustomSizeModalRect(x, y, 0F, 0F, natW, natH, w, h, natW, natH);
    }

    private boolean over(Entry e, int mx, int my) {
        int pad = Math.max(4, this.height / 150);
        return mx >= e.x - pad && mx <= e.x + e.w + pad && my >= e.y - pad && my <= e.y + e.h + pad;
    }

    private int entryAt(int mx, int my) {
        for (int i = 0; i < entries.size(); i++) if (over(entries.get(i), mx, my)) return i;
        return -1;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        float u = this.height / 900F;
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.color(1F, 1F, 1F, 1F);

        draw(BG, 0, 0, this.width, this.height, 1600, 900);

        // eyes opening in the dark (white, pulsing)
        if (eyeLife > 0) {
            float t = eyeLife / 70F;
            float a = (float) Math.sin(Math.PI * (1F - t));                  // fade in and out
            int ex = Math.round(EYE_SPOTS[eyeSpot][0] * u), ey = Math.round(EYE_SPOTS[eyeSpot][1] * u);
            int gap = Math.max(10, Math.round(16 * u)), ew = Math.max(3, Math.round(7 * u)), eh = Math.max(2, Math.round(3 * u));
            int glow = ((int) (50 * a) << 24) | 0xFFFFFF, core = ((int) (255 * a) << 24) | 0xFFFFFF;
            for (int side = 0; side < 2; side++) {
                int x0 = ex + side * gap;
                Gui.drawRect(x0 - ew, ey - eh * 2, x0 + ew * 2, ey + eh * 3, glow);
                Gui.drawRect(x0, ey, x0 + ew, ey + eh, core);
            }
        }

        int logoW = Math.round(760 * u), logoH = Math.round(logoW * 247F / 1664F);
        draw(LOGO, this.width - logoW - Math.round(20 * u), 0, logoW, logoH, 1664, 247);

        int idx = entryAt(mouseX, mouseY);
        if (idx != hoverIndex) {
            if (idx >= 0) UiAudio.hover();                                   // hover sound for every menu choice
            hoverIndex = idx;
        }
        for (int i = 0; i < entries.size(); i++) {
            Entry e = entries.get(i);
            draw(i == idx ? e.hover : e.idle, e.x, e.y, e.w, e.h, e.natW, e.natH);
        }

        draw(MADE_BY, 0, Math.round(835 * u), Math.round(204 * u), Math.round(204 * u * 72F / 552F), 552, 72);
        draw(DEV_NOTE, 0, Math.round(873 * u), Math.round(742 * u), Math.round(742 * u * 144F / 3976F), 3976, 144);

        // version, bottom-right, yellow (drawn with the game font so it always matches the current version)
        String ver = "The spoiled seed " + DISPLAY_VERSION;
        float vs = Math.max(1F, 2F * u * 1.0F + 0.4F);
        GlStateManager.pushMatrix();
        GlStateManager.translate(this.width - this.fontRendererObj.getStringWidth(ver) * vs - 6F, this.height - 11F * vs - 2F, 0F);
        GlStateManager.scale(vs, vs, 1F);
        this.fontRendererObj.drawStringWithShadow(ver, 0F, 0F, 0xFFFF55);
        GlStateManager.popMatrix();

        if (fadeIn < 40) {                                                    // slow fade-in from black
            Gui.drawRect(0, 0, this.width, this.height, ((int) (255 * (1F - (fadeIn + partialTicks) / 40F)) << 24));
        }
        GlStateManager.disableBlend();
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        if (mouseButton != 0) return;
        int idx = entryAt(mouseX, mouseY);
        if (idx < 0) return;
        UiAudio.click();
        switch (entries.get(idx).action) {
            case PLAY:    this.mc.displayGuiScreen(new GuiWorldSelection(this)); break;   // 1.9.4's single-player screen
            case MULTI:   this.mc.displayGuiScreen(new GuiMultiplayer(this)); break;
            case MODS:    this.mc.displayGuiScreen(new GuiModList(this)); break;
            case OPTIONS: this.mc.displayGuiScreen(new GuiOptions(this, this.mc.gameSettings)); break;
            case SOCIALS: this.mc.displayGuiScreen(new GuiSocials(this)); break;
            case QUIT:    this.mc.shutdown(); break;
            default: break;
        }
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        // ESC does nothing on the title screen
    }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}
