package com.spoiledseed.client;

import com.spoiledseed.SpoiledSeed;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/**
 * Jumpscare visuals (the sound is TPS S, played by the server):
 *  - 3-tick white flash  - shaking camera  - the face zooms in with glowing white eyes (bloom)
 *  - red pulse and static lines  - fade out. 3 variants change size, shake and tint.
 */
public class JumpscareHandler {
    private static final ResourceLocation SKIN = new ResourceLocation(SpoiledSeed.MODID, "textures/entity/null.png");
    private static final ResourceLocation EYES = new ResourceLocation(SpoiledSeed.MODID, "textures/entity/null_eyes.png");
    private final Random rnd = new Random();

    @SubscribeEvent
    public void onCamera(EntityViewRenderEvent.CameraSetup e) {
        if (ClientFx.jumpTicks <= 0 || !ClientConfig.screenShake) return;
        float k = ClientFx.jumpTicks / (float) ClientFx.JUMP_LEN;
        float amp = (ClientFx.jumpVariant == 1 ? 9F : 6F) * (ClientConfig.reduceFlash ? 0.4F : 1F);
        e.setPitch(e.getPitch() + (rnd.nextFloat() - 0.5F) * amp * k);
        e.setYaw(e.getYaw() + (rnd.nextFloat() - 0.5F) * amp * k);
        e.setRoll(e.getRoll() + (rnd.nextFloat() - 0.5F) * (amp + 2F) * k);
    }

    @SubscribeEvent
    public void onOverlay(RenderGameOverlayEvent.Post e) {
        if (e.getType() != RenderGameOverlayEvent.ElementType.ALL || ClientFx.jumpTicks <= 0) return;
        Minecraft mc = Minecraft.getMinecraft();
        ScaledResolution sr = e.getResolution();
        int w = sr.getScaledWidth(), h = sr.getScaledHeight();

        float prog = Math.min(1F, (ClientFx.JUMP_LEN - ClientFx.jumpTicks + e.getPartialTicks()) / ClientFx.JUMP_LEN);
        float fadeOut = prog > 0.7F ? Math.max(0F, (1F - prog) / 0.3F) : 1F;
        int variant = ClientFx.jumpVariant;

        GlStateManager.disableDepth();
        // 1) background: near-black, with a red pulse
        Gui.drawRect(0, 0, w, h, ((int) (235 * fadeOut) << 24) | 0x0A0A0E);
        float pulse = 0.5F + 0.5F * (float) Math.sin(prog * 38F);
        int redTint = variant == 2 ? 0x700000 : 0x500000;
        Gui.drawRect(0, 0, w, h, ((int) (70 * pulse * fadeOut) << 24) | redTint);

        // 2) the face: zooms in fast, shakes
        float zoom = (variant == 1 ? 0.95F : 0.75F) + 0.55F * (float) Math.pow(prog, 0.5D);
        int s = (int) (h * zoom);
        float shake = (1F - prog) * 10F;
        int x = (w - s) / 2 + (int) ((rnd.nextFloat() - 0.5F) * shake * 2F) + (variant == 2 ? w / 12 : 0);
        int y = (h - s) / 2 + (int) ((rnd.nextFloat() - 0.5F) * shake * 2F);
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        int faceBack = (int) (200 * fadeOut);
        Gui.drawRect(x, y, x + s, y + s, (faceBack << 24) | 0x2A2A30);      // grey slab so the black head has a silhouette
        GlStateManager.color(1F, 1F, 1F, fadeOut);
        mc.getTextureManager().bindTexture(SKIN);
        Gui.drawScaledCustomSizeModalRect(x, y, 8F, 8F, 8, 8, s, s, 64F, 64F);

        // 3) eyes: additive bloom, three passes growing
        GlStateManager.blendFunc(GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ONE);
        mc.getTextureManager().bindTexture(EYES);
        float glow = fadeOut * (0.8F + 0.2F * pulse);
        for (int i = 0; i < 3; i++) {
            int grow = i * (s / 40 + 1);
            GlStateManager.color(glow, glow, glow, 1F);
            Gui.drawScaledCustomSizeModalRect(x - grow, y - grow, 8F, 8F, 8, 8, s + grow * 2, s + grow * 2, 64F, 64F);
        }
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);

        // 4) static
        for (int i = 0; i < (ClientConfig.reduceFlash ? 0 : 14); i++) {
            int ly = rnd.nextInt(h);
            Gui.drawRect(0, ly, w, ly + 1 + rnd.nextInt(2), ((int) (55 * fadeOut) << 24) | 0xB0B0B0);
        }
        // 5) impact flash
        if (prog < 0.08F && !ClientConfig.reduceFlash) Gui.drawRect(0, 0, w, h, ((int) (255 * (1F - prog / 0.08F)) << 24) | 0xFFFFFF);

        GlStateManager.color(1F, 1F, 1F, 1F);
        GlStateManager.disableBlend();
        GlStateManager.enableDepth();
    }
}
