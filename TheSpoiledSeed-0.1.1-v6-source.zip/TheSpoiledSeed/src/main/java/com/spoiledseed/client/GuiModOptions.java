package com.spoiledseed.client;

import java.io.IOException;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiControls;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;

/**
 * Mod Options. Open it from: Mods list -> The Spoiled Seed -> Config (also in the main menu), key O, or the pause menu.
 * Categories: Horror, Behaviour, Fog, Audio & UI, Progress, Controls, Tools.
 * Horror / Behaviour / Fog choices are saved in your client config and sent to the server when you join a world and on
 * every change, so they also work from the main menu. Progress and Tools need a world.
 */
public class GuiModOptions extends GuiScreen {
    private static final String[] CATS = { "Horror", "Behaviour", "Fog", "Audio & UI", "Progress", "Controls", "Tools" };
    private static final int C_HORROR = 0, C_BEHAVIOUR = 1, C_FOG = 2, C_AUDIO = 3, C_PROGRESS = 4, C_CONTROLS = 5, C_TOOLS = 6;

    private static final String[] LEVELS = { "LOW", "NORMAL", "HIGH" };
    private static final String[] QUESTS = { "The First Sighting", "The Black Fog", "The Forgotten Place", "The Three Relics", "The Final Ritual" };
    private static final String[] TOOL_PAGES = { "Monster", "Events", "Multiplayer", "Sounds", "Quest" };

    /** Behaviour options: { mask bit, label }. Same bits the server uses (QuestData.optMask). */
    private static final Object[][] BEHAVIOUR = {
        { 15, "Door knocks" }, { 16, "Smart hunting" }, { 17, "Null chat" }, { 18, "Torch scares" },
        { 19, "Join message" }, { 20, "Marked player" }, { 21, "Rising danger" }, { 22, "Cave exit trail" }
    };

    /** { label, command, mode } for each Tools page. mode: 1 = close the screen after, 0 = stay open, 2 = needs a second click. */
    private static final String[][][] TOOLS = {
        // Monster
        { { "Observe", "/ss spawn observing", "1" }, { "Stalk", "/ss spawn stalking", "1" }, { "Disturbance", "/ss spawn disturbance", "1" },
          { "Chase", "/ss spawn chase", "1" }, { "Cave chase", "/ss cavechase", "1" }, { "Rush (charge)", "/ss spawn rush", "1" },
          { "Jumpscare", "/ss jumpscare", "1" }, { "Glimpse", "/ss glimpse", "1" }, { "Near my bed", "/ss bed", "1" },
          { "Remove Null", "/ss clear", "0" } },
        // Events
        { { "Footsteps", "/ss footsteps", "1" }, { "Echo steps", "/ss echo", "1" }, { "Knock", "/ss knock", "1" },
          { "Door knock", "/ss doorknock", "1" }, { "Whisper", "/ss whisper", "1" }, { "Distant sound", "/ss sound", "1" },
          { "Cave run", "/ss cave", "1" }, { "Window peek", "/ss window", "1" }, { "Torch scare", "/ss torchscare", "1" },
          { "Cursed sign", "/ss sign", "1" }, { "Torches out", "/ss torch", "1" }, { "Blackout", "/ss blackout", "1" },
          { "Door", "/ss door", "1" }, { "Chest theft", "/ss theft", "1" }, { "Redstone trail", "/ss trail", "1" } },
        // Multiplayer
        { { "Null joins (TAB)", "/ss join", "0" }, { "Null leaves", "/ss leave", "0" }, { "Mark me", "/ss mark", "0" },
          { "Null speaks", "/ss mimic", "0" }, { "Say: behind you", "/ss say I am right behind you.", "0" } },
        // Sounds
        { { "Jumpscare", "/ss play jumpscare", "0" }, { "Heartbeat", "/ss play heartbeat", "0" }, { "Whisper", "/ss play whisper", "0" },
          { "Breath", "/ss play breath", "0" }, { "Knock", "/ss play knock", "0" }, { "Door knock", "/ss play doorknock", "0" },
          { "Door break", "/ss play doorbreak", "0" }, { "Scrape", "/ss play scrape", "0" }, { "Window tap", "/ss play tap", "0" },
          { "Creak", "/ss play creak", "0" }, { "Sting", "/ss play sting", "0" }, { "Footstep", "/ss play footstep", "0" },
          { "Chase step", "/ss play chase", "0" }, { "Vanish", "/ss play vanish", "0" }, { "Drone", "/ss play drone", "0" },
          { "Seal", "/ss play seal", "0" } },
        // Quest
        { { "Status", "/ss status", "1" }, { "Locate Site", "/ss locate site", "1" }, { "Locate Shrine", "/ss locate shrine", "1" },
          { "Locate Cairn", "/ss locate cairn", "1" }, { "Locate Ruin", "/ss locate ruin", "1" }, { "Quest items", "/ss give", "1" },
          { "New guide book", "/ss guide", "1" }, { "Stage 0", "/ss stage 0", "0" }, { "Stage 4", "/ss stage 4", "0" },
          { "Threat 0", "/ss threat 0", "0" }, { "Threat 12", "/ss threat 12", "0" }, { "NEW GAME", "/ss newgame", "2" } }
    };

    private final GuiScreen parent;
    private int cat = C_HORROR, toolPage = 0;
    private int resetConfirm;                       // ticks left to confirm "NEW GAME"
    private SliderButton fogSlider;

    public GuiModOptions(GuiScreen parent) { this.parent = parent; }

    private int x0() { return this.width / 2 - 190; }
    private int top() { return Math.max(4, this.height / 2 - 112); }

    // ---- layout ---------------------------------------------------------------------------
    @Override
    public void initGui() {
        this.buttonList.clear();
        this.fogSlider = null;
        int x0 = x0(), top = top();
        for (int i = 0; i < CATS.length; i++) {
            FlatButton b = new FlatButton(100 + i, x0, top + 30 + i * 24, 92, 20, CATS[i]);
            b.selected = (i == cat);
            this.buttonList.add(b);
        }
        int cx = x0 + 102, cw = 278, y = top + 30;
        boolean inWorld = ClientConfig.inWorld();
        switch (cat) {
            case C_HORROR:
                toggle(1, cx, y, cw, "Jumpscares", ClientConfig.bit(1));
                toggle(2, cx, y + 24, cw, "Chest theft (your chests only)", ClientConfig.bit(2));
                toggle(3, cx, y + 48, cw, "Cursed signs", ClientConfig.bit(3));
                toggle(4, cx, y + 72, cw, "Ambient scares at night", ClientConfig.bit(6));
                this.buttonList.add(new FlatButton(5, cx, y + 96, cw, 20, "Horror level: " + LEVELS[Math.min(2, ClientConfig.level())]));
                break;
            case C_BEHAVIOUR:
                for (int i = 0; i < BEHAVIOUR.length; i++) {
                    int bit = ((Integer) BEHAVIOUR[i][0]).intValue();
                    String label = (String) BEHAVIOUR[i][1];
                    int bx = cx + (i % 2) * 141, by = y + (i / 2) * 24;
                    this.buttonList.add(new FlatButton(60 + i, bx, by, 137, 20, label + ": " + (ClientConfig.bit(bit) ? "ON" : "OFF")));
                }
                break;
            case C_FOG:
                toggle(10, cx, y, cw, "Black Fog", ClientConfig.bit(0));
                this.fogSlider = new SliderButton(11, cx, y + 24, cw, 20, "Fog strength", ClientConfig.fogStrength());
                this.buttonList.add(this.fogSlider);
                if (inWorld) {
                    this.buttonList.add(new FlatButton(12, cx, y + 52, cw / 2 - 2, 20, "Preview 60%"));
                    this.buttonList.add(new FlatButton(13, cx + cw / 2 + 2, y + 52, cw / 2 - 2, 20, "Back to automatic"));
                }
                break;
            case C_AUDIO:
                toggle(20, cx, y, cw, "UI sounds", ClientConfig.uiSounds);
                toggle(21, cx, y + 24, cw, "Menu music", ClientConfig.menuMusic);
                toggle(22, cx, y + 48, cw, "Reduce flashing (accessibility)", ClientConfig.reduceFlash);
                toggle(23, cx, y + 72, cw, "Camera shake", ClientConfig.screenShake);
                toggle(24, cx, y + 96, cw, "Chase distance HUD", ClientConfig.chaseHud);
                break;
            case C_PROGRESS:
                if (inWorld) {
                    this.buttonList.add(new FlatButton(30, cx, y + 144, cw / 2 - 2, 20, "Locate Site"));
                    this.buttonList.add(new FlatButton(31, cx + cw / 2 + 2, y + 144, cw / 2 - 2, 20, "Locate Shrine"));
                    this.buttonList.add(new FlatButton(32, cx, y + 166, cw / 2 - 2, 20, "Locate Cairn"));
                    this.buttonList.add(new FlatButton(33, cx + cw / 2 + 2, y + 166, cw / 2 - 2, 20, "Locate Ruin"));
                    this.buttonList.add(new FlatButton(35, cx, y + 190, cw, 20,
                            this.resetConfirm > 0 ? "CLICK AGAIN TO CONFIRM - resets ALL progress" : "NEW GAME - reset everything"));
                }
                break;
            case C_CONTROLS:
                this.buttonList.add(new FlatButton(40, cx, y + MenuHandler.ALL_KEYS.length * 14 + 8, cw, 20, "Open Controls (rebind keys)"));
                break;
            case C_TOOLS:
                if (!inWorld) break;
                this.buttonList.add(new FlatButton(49, cx, y, cw, 20, "Page: " + TOOL_PAGES[toolPage] + "  (click for next)"));
                String[][] spec = TOOLS[toolPage];
                int cols = 3, bw = (cw - 4) / cols;
                for (int i = 0; i < spec.length; i++) {
                    String label = spec[i][0];
                    if ("2".equals(spec[i][2]) && this.resetConfirm > 0) label = "CLICK AGAIN!";
                    this.buttonList.add(new FlatButton(50 + i, cx + (i % cols) * (bw + 2), y + 26 + (i / cols) * 22, bw, 20, label));
                }
                break;
            default:
                break;
        }
        this.buttonList.add(new FlatButton(99, this.width / 2 - 50, top + 246, 100, 20, "Close"));
    }

    private void toggle(int id, int x, int y, int w, String label, boolean on) {
        this.buttonList.add(new FlatButton(id, x, y, w, 20, label + ": " + (on ? "ON" : "OFF")));
    }

    private void send(String cmd) {
        if (this.mc.thePlayer != null) this.mc.thePlayer.sendChatMessage(cmd);
    }

    /** Horror / Behaviour / Fog option: saved in the client config and sent to the server (also from the main menu). */
    private void flip(int bitIndex) {
        ClientConfig.setBit(bitIndex, !ClientConfig.bit(bitIndex));
        ClientConfig.commit();
        initGui();
    }

    /** NEW GAME needs two clicks within 5 seconds. */
    private void askReset(String command) {
        if (this.resetConfirm > 0) {
            this.resetConfirm = 0;
            this.mc.displayGuiScreen(null);
            send(command);
        } else {
            this.resetConfirm = 100;
            initGui();
        }
    }

    @Override
    public void updateScreen() {
        if (this.resetConfirm > 0 && --this.resetConfirm == 0) initGui();     // the confirmation expired
    }

    // ---- actions --------------------------------------------------------------------------
    @Override
    protected void actionPerformed(GuiButton b) throws IOException {
        int id = b.id;
        if (id == 99) { this.mc.displayGuiScreen(this.parent); return; }
        if (id >= 100) { cat = id - 100; this.resetConfirm = 0; initGui(); return; }

        switch (cat) {
            case C_HORROR:
                if (id == 1) flip(1);
                else if (id == 2) flip(2);
                else if (id == 3) flip(3);
                else if (id == 4) flip(6);
                else if (id == 5) {
                    ClientConfig.setLevel((ClientConfig.level() + 1) % 3);
                    ClientConfig.commit();
                    initGui();
                }
                break;
            case C_BEHAVIOUR:
                if (id >= 60 && id < 60 + BEHAVIOUR.length) flip(((Integer) BEHAVIOUR[id - 60][0]).intValue());
                break;
            case C_FOG:
                if (id == 10) flip(0);
                else if (id == 12) send("/ss fog 60");
                else if (id == 13) send("/ss fog off");
                break;
            case C_AUDIO:
                if (id == 20) ClientConfig.uiSounds = !ClientConfig.uiSounds;
                else if (id == 21) ClientConfig.menuMusic = !ClientConfig.menuMusic;
                else if (id == 22) ClientConfig.reduceFlash = !ClientConfig.reduceFlash;
                else if (id == 23) ClientConfig.screenShake = !ClientConfig.screenShake;
                else if (id == 24) ClientConfig.chaseHud = !ClientConfig.chaseHud;
                ClientConfig.save();
                initGui();
                break;
            case C_PROGRESS:
                if (id >= 30 && id <= 33) {
                    this.mc.displayGuiScreen(null);
                    send("/ss locate " + new String[] { "site", "shrine", "cairn", "ruin" }[id - 30]);
                } else if (id == 35) {
                    askReset("/ss newgame");
                }
                break;
            case C_CONTROLS:
                if (id == 40) this.mc.displayGuiScreen(new GuiControls(this, this.mc.gameSettings));
                break;
            case C_TOOLS:
                if (id == 49) { toolPage = (toolPage + 1) % TOOLS.length; this.resetConfirm = 0; initGui(); }
                else if (id >= 50) {
                    String[] s = TOOLS[toolPage][id - 50];
                    if ("2".equals(s[2])) { askReset(s[1]); break; }
                    if ("1".equals(s[2])) this.mc.displayGuiScreen(null);
                    send(s[1]);
                }
                break;
            default:
                break;
        }
    }

    @Override
    protected void mouseReleased(int mouseX, int mouseY, int state) {
        boolean wasDragging = this.fogSlider != null && this.fogSlider.dragging;
        super.mouseReleased(mouseX, mouseY, state);
        if (wasDragging) {
            ClientConfig.setFogStrength(this.fogSlider.value);
            ClientConfig.commit();
        }
    }

    // ---- hints (shown for the button under the mouse) ------------------------------------
    private static String[] hint(int cat, int id) {
        if (cat == C_HORROR) {
            switch (id) {
                case 1: return new String[] { "Sudden screams: random, from signs, and", "when it catches you." };
                case 2: return new String[] { "It takes small items from chests YOU placed", "and hides them nearby (never quest items)." };
                case 3: return new String[] { "Threatening signs appear around you.", "Breaking one can trigger a scare." };
                case 4: return new String[] { "Whispers and distant sounds at night.", "" };
                case 5: return new String[] { "LOW / NORMAL / HIGH: how often it comes.", "" };
                default: return null;
            }
        }
        if (cat == C_BEHAVIOUR) {
            switch (id) {
                case 60: return new String[] { "It knocks at your door and may break it down", "(60%) and charge at you. The door drops." };
                case 61: return new String[] { "Dashes when you sprint, leaps gaps, breaks", "your walls, builds black blocks to reach you." };
                case 62: return new String[] { "The Null writes unsettling messages in chat.", "" };
                case 63: return new String[] { "Breaking torches can cause a scare; at night:", "10 seconds of darkness, then a glimpse." };
                case 64: return new String[] { "'Null joined the game' one minute after you", "join, and Null appears in the TAB list." };
                case 65: return new String[] { "Multiplayer: it picks one player at a time", "and hunts them harder." };
                case 66: return new String[] { "Every in-game day and every hour of play", "makes it faster, bolder and more frequent." };
                case 67: return new String[] { "Redstone dust is left on the ground where", "you come out of a cave." };
                default: return null;
            }
        }
        if (cat == C_FOG && id == 10) return new String[] { "The fog is there from the moment you spawn.", "" };
        if (cat == C_PROGRESS && id == 35) return new String[] { "Resets story, threat, play time and what it", "learned. Options are kept. Click twice." };
        return null;
    }

    // ---- drawing --------------------------------------------------------------------------
    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.drawDefaultBackground();
        int x0 = x0(), top = top();
        Gui.drawRect(x0 - 10, top - 8, x0 + 390, top + 272, 0xB0000000);
        Gui.drawRect(x0 + 96, top + 26, x0 + 97, top + 242, 0x40FFFFFF);          // divider

        GlStateManager.pushMatrix();
        GlStateManager.translate(this.width / 2F, top + 2F, 0F);
        GlStateManager.scale(1.6F, 1.6F, 1F);
        this.drawCenteredString(this.fontRendererObj, "THE SPOILED SEED  -  MOD OPTIONS", 0, 0, 0xC8C8C8);
        GlStateManager.popMatrix();

        int cx = x0 + 102, y = top + 30;
        boolean inWorld = ClientConfig.inWorld();
        if (cat == C_HORROR || cat == C_BEHAVIOUR) {
            this.drawString(this.fontRendererObj, inWorld ? "Saved and applied to this world now." : "Saved now, applied when you join a world.", cx, y + (cat == C_HORROR ? 124 : 104), 0x909090);
        } else if (cat == C_FOG) {
            this.drawString(this.fontRendererObj, "Strength scales every kind of fog. 0% = clear.", cx, y + 80, 0x707070);
            if (!inWorld) this.drawString(this.fontRendererObj, "Saved now, applied when you join a world.", cx, y + 94, 0x909090);
        } else if (cat == C_AUDIO) {
            this.drawString(this.fontRendererObj, "Music volume: Options > Music & Sounds.", cx, y + 124, 0x707070);
        } else if (cat == C_PROGRESS) {
            if (inWorld) drawProgress(cx, y); else this.drawString(this.fontRendererObj, "Join a world to see your progress.", cx, y, 0x909090);
        } else if (cat == C_CONTROLS) {
            drawControls(cx, y);
        } else if (cat == C_TOOLS) {
            if (!inWorld) this.drawString(this.fontRendererObj, "Join a world to use the tools (they run /ss commands).", cx, y, 0x909090);
            else this.drawString(this.fontRendererObj, "No cooldowns. (/ss needs op if openCommands=false)", cx, y + 26 + 22 * ((TOOLS[toolPage].length + 2) / 3), 0x707070);
        }
        super.drawScreen(mouseX, mouseY, partialTicks);

        for (GuiButton b : this.buttonList) {                                       // hint for the hovered button
            if (b.id >= 99 || !b.isMouseOver()) continue;
            String[] h = hint(cat, b.id);
            if (h == null) continue;
            this.drawCenteredString(this.fontRendererObj, h[0], this.width / 2 + 50, top + 216, 0xB8B8B8);
            this.drawCenteredString(this.fontRendererObj, h[1], this.width / 2 + 50, top + 228, 0xB8B8B8);
            break;
        }
    }

    private void drawProgress(int cx, int y) {
        for (int i = 0; i < QUESTS.length; i++) {
            boolean done = i < ClientFx.stage, now = i == ClientFx.stage;
            String mark = done ? "[x] " : now ? "[>] " : "[ ] ";
            int color = done ? 0x55FF55 : now ? 0xFFDD55 : 0x777777;
            this.drawString(this.fontRendererObj, mark + (i + 1) + ". " + QUESTS[i], cx, y + i * 12, color);
        }
        int t = ClientFx.threat;
        this.drawString(this.fontRendererObj, "Threat: " + t + " / 12", cx, y + 66, t >= 8 ? 0xFF5555 : t >= 4 ? 0xFFAA55 : 0xCCCCCC);
        Gui.drawRect(cx, y + 77, cx + 200, y + 83, 0x90000000);
        Gui.drawRect(cx, y + 77, cx + 200 * t / 12, y + 83, t >= 8 ? 0xFFCC2222 : 0xFFB0B0B0);
        long day = this.mc.theWorld != null ? this.mc.theWorld.getTotalWorldTime() / 24000L : 0L;
        float pressure = Math.min(2F, day * 0.05F + (ClientFx.minutes / 60F) * 0.15F);
        this.drawString(this.fontRendererObj, "Play time: " + (int) (ClientFx.minutes / 60) + " h " + ((int) ClientFx.minutes % 60) + " min   |   World day " + day, cx, y + 90, 0xB0B0B0);
        this.drawString(this.fontRendererObj, "Danger from time: " + String.format("%.2f", pressure) + " / 2.00", cx, y + 103, pressure >= 1.2F ? 0xFF5555 : 0xCCCCCC);
        Gui.drawRect(cx, y + 114, cx + 200, y + 120, 0x90000000);
        Gui.drawRect(cx, y + 114, cx + (int) (200 * pressure / 2F), y + 120, 0xFFB0B0B0);
        this.drawString(this.fontRendererObj, "Every day, hour and ritual item makes it worse.", cx, y + 126, 0x707070);
    }

    private void drawControls(int cx, int y) {
        for (int i = 0; i < MenuHandler.ALL_KEYS.length; i++) {
            KeyBinding k = MenuHandler.ALL_KEYS[i];
            String key = k.getKeyCode() == 0 ? "not bound" : GameSettings.getKeyDisplayString(k.getKeyCode());
            this.drawString(this.fontRendererObj, I18n.format(k.getKeyDescription()), cx, y + i * 14, 0xD0D0D0);
            this.drawString(this.fontRendererObj, "[" + key + "]", cx + 190, y + i * 14, k.getKeyCode() == 0 ? 0x777777 : 0xFFDD55);
        }
    }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}
