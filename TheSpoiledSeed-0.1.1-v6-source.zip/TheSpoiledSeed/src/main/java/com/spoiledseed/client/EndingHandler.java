package com.spoiledseed.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/** "THE WORLD IS QUIET AGAIN." ... "BUT SOMETHING REMAINS..." */
public class EndingHandler {
    @SubscribeEvent
    public void onOverlay(RenderGameOverlayEvent.Post e) {
        if (e.getType() != RenderGameOverlayEvent.ElementType.ALL || ClientFx.endingTick < 0) return;
        Minecraft mc = Minecraft.getMinecraft();
        ScaledResolution sr = e.getResolution();
        int t = ClientFx.endingTick;
        draw(mc, "THE WORLD IS QUIET AGAIN.", sr.getScaledWidth(), sr.getScaledHeight(), fade(t, 30, 200));
        draw(mc, "BUT SOMETHING REMAINS...", sr.getScaledWidth(), sr.getScaledHeight(), fade(t, 300, 480));
    }

    private static float fade(int t, int start, int end) {
        float in = Math.min(1F, (t - start) / 30F);
        float out = Math.min(1F, (end - t) / 30F);
        return Math.max(0F, Math.min(in, out));
    }

    private static void draw(Minecraft mc, String s, int w, int h, float alpha) {
        int a = (int) (255 * alpha);
        if (a < 8) return;
        GlStateManager.pushMatrix();
        GlStateManager.enableBlend();
        GlStateManager.translate(w / 2F, h / 2F, 0F);
        GlStateManager.scale(2.5F, 2.5F, 1F);
        mc.fontRendererObj.drawStringWithShadow(s, -mc.fontRendererObj.getStringWidth(s) / 2F, -4F, (a << 24) | 0xE0E0E0);
        GlStateManager.popMatrix();
    }
}
