package com.spoiledseed.client;

import com.spoiledseed.SpoiledSeed;
import java.io.IOException;
import java.net.URI;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

/** The author's accounts: Open (browser) or Copy (clipboard) for each. */
public class GuiSocials extends GuiScreen {
    private static final ResourceLocation BG = new ResourceLocation(SpoiledSeed.MODID, "textures/gui/background.png");
    /** { platform, handle, url } */
    private static final String[][] LINKS = {
        { "Instagram", "@zero963._0", "https://www.instagram.com/zero963._0?avpt=YjZ3YWhleXUwaWFw" },
        { "YouTube", "@0zero9630", "https://youtube.com/@0zero9630?si=SOomevtT2lzqmgjG" },
        { "GitHub", "Zero (project page)", "https://share.google/3bWRBznbYHQmrmh3G" }
    };

    private final GuiScreen parent;
    private String status = "";
    private int statusTicks;

    public GuiSocials(GuiScreen parent) { this.parent = parent; }

    @Override
    public void initGui() {
        this.buttonList.clear();
        int cx = this.width / 2, y = this.height / 2 - 34;
        for (int i = 0; i < LINKS.length; i++) {
            this.buttonList.add(new FlatButton(i, cx + 40, y + i * 34, 70, 22, "Open"));
            this.buttonList.add(new FlatButton(20 + i, cx + 114, y + i * 34, 56, 22, "Copy"));
        }
        this.buttonList.add(new FlatButton(99, cx - 60, y + LINKS.length * 34 + 14, 120, 22, "Back"));
    }

    @Override
    protected void actionPerformed(GuiButton b) throws IOException {
        if (b.id == 99) { this.mc.displayGuiScreen(this.parent); return; }
        if (b.id >= 20 && b.id < 20 + LINKS.length) {
            setClipboardString(LINKS[b.id - 20][2]);
            say(LINKS[b.id - 20][0] + " link copied to the clipboard.");
        } else if (b.id >= 0 && b.id < LINKS.length) {
            open(LINKS[b.id][2], LINKS[b.id][0]);
        }
    }

    private void say(String s) { this.status = s; this.statusTicks = 120; }

    private void open(String url, String name) {
        try {
            Class<?> c = Class.forName("java.awt.Desktop");
            Object d = c.getMethod("getDesktop").invoke(null);
            c.getMethod("browse", URI.class).invoke(d, new URI(url));
            say("Opening " + name + " in your browser...");
        } catch (Throwable t) {
            setClipboardString(url);
            say("Could not open a browser - the " + name + " link was copied instead.");
        }
    }

    @Override
    public void updateScreen() { if (statusTicks > 0) statusTicks--; }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        GlStateManager.color(1F, 1F, 1F, 1F);
        this.mc.getTextureManager().bindTexture(BG);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
        Gui.drawScaledCustomSizeModalRect(0, 0, 0F, 0F, 1600, 900, this.width, this.height, 1600F, 900F);
        Gui.drawRect(0, 0, this.width, this.height, 0xB0000000);

        int cx = this.width / 2, y = this.height / 2 - 34;
        Gui.drawRect(cx - 180, y - 74, cx + 180, y + LINKS.length * 34 + 52, 0x80000000);   // panel

        GlStateManager.pushMatrix();
        GlStateManager.translate(cx, y - 62F, 0F);
        GlStateManager.scale(2.4F, 2.4F, 1F);
        this.drawCenteredString(this.fontRendererObj, "SOCIALS", 0, 0, 0xC8C8C8);
        GlStateManager.popMatrix();
        this.drawCenteredString(this.fontRendererObj, "Follow the creator - made by Zero", cx, y - 34, 0x808080);

        for (int i = 0; i < LINKS.length; i++) {
            this.drawString(this.fontRendererObj, LINKS[i][0], cx - 165, y + i * 34 + 2, 0xE0E0E0);
            this.drawString(this.fontRendererObj, LINKS[i][1], cx - 165, y + i * 34 + 13, 0x808080);
        }
        super.drawScreen(mouseX, mouseY, partialTicks);
        if (statusTicks > 0) this.drawCenteredString(this.fontRendererObj, this.status, cx, y + LINKS.length * 34 + 42, 0xB0B0B0);
    }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}
