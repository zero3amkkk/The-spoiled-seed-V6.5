package com.spoiledseed.network;

import com.spoiledseed.horror.HorrorDirector;
import com.spoiledseed.quest.QuestData;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.world.WorldServer;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

/** Client -> server: the player's Mod Options (same bit mask as PacketFx.OPTIONS). Sent when joining and on every change. */
public class PacketOptions implements IMessage {
    public int mask;

    public PacketOptions() {}
    public PacketOptions(int mask) { this.mask = mask; }

    @Override
    public void fromBytes(ByteBuf buf) { mask = buf.readInt(); }

    @Override
    public void toBytes(ByteBuf buf) { buf.writeInt(mask); }

    public static class Handler implements IMessageHandler<PacketOptions, IMessage> {
        @Override
        public IMessage onMessage(final PacketOptions m, final MessageContext ctx) {
            final EntityPlayerMP p = ctx.getServerHandler().playerEntity;
            ((WorldServer) p.worldObj).addScheduledTask(new Runnable() {
                @Override
                public void run() {
                    QuestData.applyMask(p, m.mask);
                    HorrorDirector.sendOptions(p);
                }
            });
            return null;
        }
    }
}
