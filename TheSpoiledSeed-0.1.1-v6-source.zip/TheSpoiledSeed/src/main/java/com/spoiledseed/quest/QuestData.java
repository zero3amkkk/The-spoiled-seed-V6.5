package com.spoiledseed.quest;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.math.BlockPos;

/** Per-player data in Forge's persisted NBT (survives death and restarts): progress, threat, options, tracked blocks. */
public class QuestData {
    public static NBTTagCompound get(EntityPlayer p) {
        NBTTagCompound root = p.getEntityData();
        if (!root.hasKey(EntityPlayer.PERSISTED_NBT_TAG)) root.setTag(EntityPlayer.PERSISTED_NBT_TAG, new NBTTagCompound());
        NBTTagCompound pers = root.getCompoundTag(EntityPlayer.PERSISTED_NBT_TAG);
        if (!pers.hasKey("SpoiledSeed")) pers.setTag("SpoiledSeed", new NBTTagCompound());
        return pers.getCompoundTag("SpoiledSeed");
    }

    // ---- progress ---------------------------------------------------------------------------
    /** Completed main quests (0..5). 5 = finished. */
    public static int getStage(EntityPlayer p) { return get(p).getInteger("Stage"); }
    public static void setStage(EntityPlayer p, int v) { get(p).setInteger("Stage", v); }
    public static int getSeconds(EntityPlayer p) { return get(p).getInteger("Seconds"); }
    public static void addSeconds(EntityPlayer p, int n) { get(p).setInteger("Seconds", getSeconds(p) + n); }
    public static boolean isSealed(EntityPlayer p) { return get(p).getBoolean("Sealed"); }
    public static void setSealed(EntityPlayer p, boolean v) { get(p).setBoolean("Sealed", v); }
    public static boolean isGuideGiven(EntityPlayer p) { return get(p).getBoolean("GuideGiven"); }
    public static void setGuideGiven(EntityPlayer p, boolean v) { get(p).setBoolean("GuideGiven", v); }

    // ---- threat: grows every time the player finds a ritual item, makes The Null more frequent and deadlier ----
    public static final int MAX_THREAT = 12;
    public static int getThreat(EntityPlayer p) { return get(p).getInteger("Threat"); }
    public static void setThreat(EntityPlayer p, int v) { get(p).setInteger("Threat", Math.max(0, Math.min(MAX_THREAT, v))); }
    public static int getSeen(EntityPlayer p, String key) { return get(p).getInteger("Seen_" + key); }
    public static void setSeen(EntityPlayer p, String key, int v) { get(p).setInteger("Seen_" + key, v); }

    // ---- per-player options (Mod Options screen) --------------------------------------------
    private static boolean opt(EntityPlayer p, String key) {
        NBTTagCompound t = get(p);
        return !t.hasKey(key) || t.getBoolean(key);              // default: ON
    }
    public static boolean optFog(EntityPlayer p) { return opt(p, "OptFog"); }
    public static boolean optJump(EntityPlayer p) { return opt(p, "OptJump"); }
    public static boolean optTheft(EntityPlayer p) { return opt(p, "OptTheft"); }
    public static boolean optSigns(EntityPlayer p) { return opt(p, "OptSigns"); }
    public static boolean optAmbient(EntityPlayer p) { return opt(p, "OptAmbient"); }
    public static boolean optDoor(EntityPlayer p) { return opt(p, "OptDoor"); }      // knocks at / breaks your door
    public static boolean optAdapt(EntityPlayer p) { return opt(p, "OptAdapt"); }    // dashes when you sprint, builds black blocks
    public static boolean optChat(EntityPlayer p) { return opt(p, "OptChat"); }      // writes in chat
    public static boolean optTorch(EntityPlayer p) { return opt(p, "OptTorch"); }    // torch scares
    public static boolean optJoin(EntityPlayer p) { return opt(p, "OptJoin"); }      // "Null joined the game"
    public static boolean optMark(EntityPlayer p) { return opt(p, "OptMark"); }      // multiplayer: can be marked
    public static boolean optTime(EntityPlayer p) { return opt(p, "OptTime"); }      // danger grows with days and hours
    public static boolean optTrail(EntityPlayer p) { return opt(p, "OptTrail"); }    // redstone trail at cave exits
    /** Fog strength 0..100 (default 100 = as designed). Scales every kind of fog. */
    public static int optFogStrength(EntityPlayer p) {
        NBTTagCompound t = get(p);
        return t.hasKey("OptFogStrength") ? Math.max(0, Math.min(100, t.getInteger("OptFogStrength"))) : 100;
    }
    public static void setFogStrength(EntityPlayer p, int v) { get(p).setInteger("OptFogStrength", Math.max(0, Math.min(100, v))); }
    public static void setOpt(EntityPlayer p, String name, boolean v) { get(p).setBoolean("Opt" + name, v); }
    /** Horror level: 0 low, 1 normal, 2 high. */
    public static int optLevel(EntityPlayer p) {
        NBTTagCompound t = get(p);
        return t.hasKey("OptLevel") ? Math.max(0, Math.min(2, t.getInteger("OptLevel"))) : 1;
    }
    public static void setLevel(EntityPlayer p, int v) { get(p).setInteger("OptLevel", Math.max(0, Math.min(2, v))); }

    /** bit0 fog, 1 jumpscare, 2 theft, 3 signs, 4-5 level, 6 ambient, 8-14 fog strength, 15 door, 16 adapt, 17 chat, 18 torch, 19 join msg, 20 marked, 21 time. */
    public static int optMask(EntityPlayer p) {
        return (optFog(p) ? 1 : 0) | (optJump(p) ? 2 : 0) | (optTheft(p) ? 4 : 0) | (optSigns(p) ? 8 : 0)
                | (optLevel(p) << 4) | (optAmbient(p) ? 64 : 0) | (optFogStrength(p) << 8)
                | (optDoor(p) ? 1 << 15 : 0) | (optAdapt(p) ? 1 << 16 : 0) | (optChat(p) ? 1 << 17 : 0) | (optTorch(p) ? 1 << 18 : 0)
                | (optJoin(p) ? 1 << 19 : 0) | (optMark(p) ? 1 << 20 : 0) | (optTime(p) ? 1 << 21 : 0) | (optTrail(p) ? 1 << 22 : 0);
    }

    /** Applies an option mask sent by the player's Mod Options screen. */
    public static void applyMask(EntityPlayer p, int mask) {
        setOpt(p, "Fog", (mask & 1) != 0);
        setOpt(p, "Jump", (mask & 2) != 0);
        setOpt(p, "Theft", (mask & 4) != 0);
        setOpt(p, "Signs", (mask & 8) != 0);
        setLevel(p, (mask >> 4) & 3);
        setOpt(p, "Ambient", (mask & 64) != 0);
        setFogStrength(p, (mask >> 8) & 127);
        setOpt(p, "Door", (mask & (1 << 15)) != 0);
        setOpt(p, "Adapt", (mask & (1 << 16)) != 0);
        setOpt(p, "Chat", (mask & (1 << 17)) != 0);
        setOpt(p, "Torch", (mask & (1 << 18)) != 0);
        setOpt(p, "Join", (mask & (1 << 19)) != 0);
        setOpt(p, "Mark", (mask & (1 << 20)) != 0);
        setOpt(p, "Time", (mask & (1 << 21)) != 0);
        setOpt(p, "Trail", (mask & (1 << 22)) != 0);
    }

    /** NEW GAME: everything about the story and the monster starts from zero. Options and the guide book are kept. */
    public static void resetAll(EntityPlayer p) {
        NBTTagCompound t = get(p);
        t.setInteger("Stage", 0);
        t.setInteger("Seconds", 0);
        t.setBoolean("Sealed", false);
        t.setInteger("Threat", 0);
        for (String k : new String[] { "sample", "echo", "core", "seal", "journal" }) t.removeTag("Seen_" + k);
        t.removeTag("Chests");
        t.removeTag("Signs");
        t.removeTag("Zones");
    }

    // ---- tracked block positions (player-placed chests, cursed signs) ----------------------
    public static void addPos(EntityPlayer p, String key, BlockPos pos, int cap) {
        NBTTagList list = get(p).getTagList(key, 10);
        NBTTagCompound c = new NBTTagCompound();
        c.setLong("p", pos.toLong());
        list.appendTag(c);
        while (list.tagCount() > cap) list.removeTag(0);
        get(p).setTag(key, list);
    }

    public static List<BlockPos> getPositions(EntityPlayer p, String key) {
        NBTTagList list = get(p).getTagList(key, 10);
        List<BlockPos> out = new ArrayList<BlockPos>();
        for (int i = 0; i < list.tagCount(); i++) out.add(BlockPos.fromLong(list.getCompoundTagAt(i).getLong("p")));
        return out;
    }

    public static boolean removePos(EntityPlayer p, String key, BlockPos pos) {
        NBTTagList list = get(p).getTagList(key, 10);
        for (int i = 0; i < list.tagCount(); i++) {
            if (list.getCompoundTagAt(i).getLong("p") == pos.toLong()) { list.removeTag(i); return true; }
        }
        return false;
    }

    public static boolean hasPos(EntityPlayer p, String key, BlockPos pos) {
        NBTTagList list = get(p).getTagList(key, 10);
        for (int i = 0; i < list.tagCount(); i++) if (list.getCompoundTagAt(i).getLong("p") == pos.toLong()) return true;
        return false;
    }
}
