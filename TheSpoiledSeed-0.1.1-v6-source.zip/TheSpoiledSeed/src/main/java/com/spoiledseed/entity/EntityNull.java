package com.spoiledseed.entity;

import com.spoiledseed.config.ModConfig;
import com.spoiledseed.horror.HorrorDirector;
import com.spoiledseed.horror.Jumpscare;
import com.spoiledseed.horror.NullBlocks;
import com.spoiledseed.network.NetworkHandler;
import com.spoiledseed.network.PacketFx;
import com.spoiledseed.quest.QuestData;
import com.spoiledseed.quest.QuestManager;
import com.spoiledseed.registry.ModBlocks;
import com.spoiledseed.registry.ModSounds;
import java.util.UUID;
import net.minecraft.block.BlockDoor;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIOpenDoor;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.SoundEvents;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.pathfinding.PathNavigateGround;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

/**
 * THE NULL. Gameplay runs server-side in updateAITasks(); the client reads two synced values:
 * STATE and ALPHA (fade in / out so it blends into the scene). It owns no persistent data:
 * without an owner player it removes itself (no duplicates after a reload).
 *
 * It adapts to what the player does:
 *   - looks at it too long      -> it may CHARGE
 *   - sprints during a chase    -> 25%: it DASHES, catches you and screams (jumpscare)
 *   - hides high on blocks      -> it builds black Null Blocks up to you, then hits you or jumpscares
 *   - sneaks / sprints / mines  -> it loses you / hears you
 *   - shuts itself in           -> it knocks on the door and may break it
 *   - survives hunts            -> it learns (faster, bolder); time and threat make everything worse
 */
public class EntityNull extends EntityCreature {
    private static final DataParameter<Integer> STATE = EntityDataManager.<Integer>createKey(EntityNull.class, DataSerializers.VARINT);
    private static final DataParameter<Float> ALPHA = EntityDataManager.<Float>createKey(EntityNull.class, DataSerializers.FLOAT);

    public static final int FADE_IN_TICKS = 30;
    public static final int VANISH_TICKS = 18;

    private UUID ownerId;
    private int stateTicks, lifeTicks, maxLife = 600, lookedTicks, attackCooldown, searchTicks, chaseTicksLeft;
    private int stallTicks, burstTicks, threat;
    private float adapt;                    // it LEARNS: grows every time you survive a hunt (0..1)
    private float pressure;                 // grows with in-game days and play hours (0..2)
    private float escalateChance, lastAlpha = -1F;
    private float closeVanish = 9.0F;
    private boolean ritual, rush, noRush;
    private BlockPos lastKnown;
    private double sampleX, sampleZ, velX, velZ;
    private boolean sampled;

    // door knocking
    private BlockPos doorPos;
    private int doorKnockTimer, doorKnocks;
    private boolean doorRush;
    // sprint dash
    private boolean dashing;
    private int dashTicks, dashCooldown;
    // leaping across a gap between two platforms
    private int leapTicks, gapTicks;
    private Vec3d leapFrom, leapTo;
    // you walled yourself in: it breaks through, then stares for 5 seconds, then screams
    private int noPathTicks, barrierBreaks, breakTimer, stareTicks;
    private boolean stareDone;
    // you are standing OUTSIDE the door it is knocking on
    private int noticedTicks;
    // tower hunting (builds black blocks up to a player who hides high)
    private boolean towerMode, towerResolved;
    private int towerTicks, towerBuildTimer, towerFails;

    public EntityNull(World world) {
        super(world);
        this.setSize(0.6F, 1.8F);
        this.isImmuneToFire = true;
        this.tasks.addTask(0, new EntityAISwimming(this));
        ((PathNavigateGround) this.getNavigator()).setCanSwim(true);
        ((PathNavigateGround) this.getNavigator()).setBreakDoors(true);     // paths through doors...
        this.tasks.addTask(1, new EntityAIOpenDoor(this, false));          // ...and opens them: a closed door will not save you
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        this.dataManager.register(STATE, Integer.valueOf(0));
        this.dataManager.register(ALPHA, Float.valueOf(0F));
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(40.0D);
        this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.23D);
        this.getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(64.0D);
        this.getAttributeMap().registerAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(3.0D);
    }

    @Override
    protected boolean canDespawn() { return false; }

    // ---- synced values ------------------------------------------------------------------
    public NullState getState() { return NullState.byId(this.dataManager.get(STATE).intValue()); }
    public float getAlpha() { return this.dataManager.get(ALPHA).floatValue(); }

    public void setState(NullState s) {
        this.dataManager.set(STATE, Integer.valueOf(s.ordinal()));
        this.stateTicks = 0;
        this.lookedTicks = 0;
        double speed = 0.23D;
        if (s == NullState.CHASE) speed = this.chaseSpeed();
        this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(speed);
        if (s == NullState.CHASE) {
            double dur = ModConfig.chaseDurationSeconds * 20 * (0.8D + this.rand.nextDouble() * 0.4D) * (1D + this.threat * 0.06D + this.pressure * 0.1D);
            this.chaseTicksLeft = this.rush ? 220 : (int) dur;
            this.searchTicks = 0;
            this.stallTicks = 0;
            this.burstTicks = 0;
        }
    }

    private double chaseSpeed() {
        return ModConfig.chaseSpeed + Math.min(0.06D, this.threat * 0.006D) + this.adapt * 0.04D
                + Math.min(0.03D, this.pressure * 0.012D) + (this.rush ? 0.05D : 0D);
    }

    private void setSpeed(double v) {
        this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(v);
    }

    /** Called once by SpawnHelper right after construction (server side). */
    public void init(EntityPlayer owner, NullState state, int maxLifeTicks, boolean ritualMode, float escalate) {
        this.ownerId = owner.getUniqueID();
        this.maxLife = maxLifeTicks;
        this.ritual = ritualMode;
        this.escalateChance = escalate;
        this.threat = QuestData.getThreat(owner);
        this.adapt = HorrorDirector.rec(owner).adapt;
        this.pressure = HorrorDirector.pressure(owner);
        this.getAttributeMap().getAttributeInstance(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(
                ModConfig.chaseDamage + this.threat * 0.25F + this.pressure * 0.4F);
        this.setState(state);
        this.faceEntity(owner, 360.0F, 360.0F);
        this.rotationYawHead = this.rotationYaw;
    }

    /** Window peeks / glimpses: it only wants to be SEEN. It leaves when you get near and never charges. */
    public void setPeekMode(float vanishDistance) {
        this.closeVanish = vanishDistance;
        this.noRush = true;
    }

    /** It stands in front of this (lower) door half and knocks. */
    public void setDoorTarget(BlockPos lowerDoor) {
        this.doorPos = lowerDoor;
        this.doorKnockTimer = 30;
        this.doorKnocks = 0;
        this.noRush = true;
    }

    /** Debug / commands: make it charge right now. */
    public void forceRush() {
        this.rush = true;
        this.noRush = false;
        this.setState(NullState.CHASE);
    }

    // ---- client: dark halo particles ------------------------------------------------------
    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();
        if (this.worldObj.isRemote && this.getAlpha() > 0.15F) {
            // SPELL_MOB takes its colour from the speed arguments: (0,0,0) = pure black swirls around the body
            for (int i = 0; i < 4; i++) {
                this.worldObj.spawnParticle(EnumParticleTypes.SPELL_MOB,
                        this.posX + (this.rand.nextDouble() - 0.5D) * 1.1D,
                        this.posY + this.rand.nextDouble() * 2.0D,
                        this.posZ + (this.rand.nextDouble() - 0.5D) * 1.1D,
                        0.0D, 0.0D, 0.0D);
            }
            if (this.rand.nextInt(3) == 0) {
                this.worldObj.spawnParticle(EnumParticleTypes.SMOKE_LARGE,
                        this.posX + (this.rand.nextDouble() - 0.5D) * 1.2D,
                        this.posY + 0.2D + this.rand.nextDouble() * 1.6D,
                        this.posZ + (this.rand.nextDouble() - 0.5D) * 1.2D,
                        0.0D, 0.01D, 0.0D);
            }
        }
    }

    // ---- server brain ---------------------------------------------------------------------
    @Override
    protected void updateAITasks() {
        super.updateAITasks();
        if (this.worldObj.isRemote) return;

        EntityPlayer p = this.ownerId == null ? null : this.worldObj.getPlayerEntityByUUID(this.ownerId);
        if (p == null || p.isDead) { this.setDead(); return; }
        this.stateTicks++;
        this.lifeTicks++;
        if (this.attackCooldown > 0) this.attackCooldown--;
        this.updateAlpha();
        this.sampleVelocity(p);

        NullState st = this.getState();
        if (st != NullState.VANISHING && QuestData.isSealed(p)) { this.vanish(); return; }
        switch (st) {
            case OBSERVING:    this.tickObserving(p);   break;
            case STALKING:     this.tickStalking(p);    break;
            case DISTURBANCE:  this.tickDisturbance(p); break;
            case CHASE:        this.tickChase(p);       break;
            case JUMPSCARE:
                this.getNavigator().clearPathEntity();
                this.getLookHelper().setLookPositionWithEntity(p, 40.0F, 40.0F);
                if (this.stateTicks > 30) this.vanish();
                break;
            case VANISHING:
                this.getNavigator().clearPathEntity();
                if (this.stateTicks % 2 == 0) this.darkParticles(4);
                if (this.stateTicks >= VANISH_TICKS) this.setDead();
                break;
        }
        // HUD: distance readout above the hearts while it hunts you
        if (p instanceof EntityPlayerMP && this.getState() == NullState.CHASE && this.ticksExisted % 5 == 0) {
            NetworkHandler.CHANNEL.sendTo(new PacketFx(PacketFx.CHASE_DIST, this.getDistanceToEntity(p)), (EntityPlayerMP) p);
        }
    }

    /** Player velocity (blocks per tick) measured every 8 ticks, used to predict where you run. */
    private void sampleVelocity(EntityPlayer p) {
        if (this.ticksExisted % 8 != 0) return;
        if (!this.sampled) { this.sampleX = p.posX; this.sampleZ = p.posZ; this.velX = 0D; this.velZ = 0D; this.sampled = true; return; }
        this.velX = (p.posX - this.sampleX) / 8.0D;
        this.velZ = (p.posZ - this.sampleZ) / 8.0D;
        this.sampleX = p.posX;
        this.sampleZ = p.posZ;
    }

    /** It RUNS at you: fast charge that ends in a jumpscare or a kill (see onCatch). */
    private boolean tryRush(EntityPlayer p) {
        float chance = Math.min(0.95F, ModConfig.rushChance + this.adapt * 0.25F + this.pressure * 0.08F);
        if (this.ritual || this.noRush || QuestData.getStage(p) < 1 || this.rand.nextFloat() >= chance) return false;
        this.rush = true;
        this.setState(NullState.CHASE);
        this.worldObj.playSound(null, this.posX, this.posY, this.posZ, ModSounds.BREATH, SoundCategory.HOSTILE, 1.6F, 0.6F);
        this.worldObj.playSound(null, this.posX, this.posY, this.posZ, ModSounds.STING, SoundCategory.HOSTILE, 0.9F, 1.0F);
        return true;
    }

    /** Fade in when it appears, fade out when it vanishes: the entity blends into the environment. */
    private void updateAlpha() {
        NullState st = this.getState();
        float a;
        if (st == NullState.VANISHING) a = 1.0F - this.stateTicks / (float) VANISH_TICKS;
        else if (st == NullState.JUMPSCARE) a = 1.0F;
        else a = Math.min(1.0F, this.lifeTicks / (float) FADE_IN_TICKS);
        a = Math.max(0.0F, Math.min(1.0F, a));
        if (Math.abs(a - this.lastAlpha) > 0.02F || (a >= 1.0F && this.lastAlpha < 1.0F)) {
            this.dataManager.set(ALPHA, Float.valueOf(a));
            this.lastAlpha = a;
        }
    }

    // STATE 1: OBSERVING - stand still and watch
    private void tickObserving(EntityPlayer p) {
        this.getNavigator().clearPathEntity();
        this.getLookHelper().setLookPositionWithEntity(p, 30.0F, 30.0F);
        if (this.getDistanceToEntity(p) < this.closeVanish) { this.vanish(); return; }
        if (this.isLookedAt(p)) this.lookedTicks++; else this.lookedTicks = Math.max(0, this.lookedTicks - 1);
        if (this.lookedTicks > 50) { if (!this.tryRush(p)) this.vanish(); return; }
        if (this.lifeTicks > this.maxLife) this.vanish();
    }

    // STATE 2: STALKING - creeps closer only while the player is not looking
    private void tickStalking(EntityPlayer p) {
        this.getLookHelper().setLookPositionWithEntity(p, 30.0F, 30.0F);
        double d = this.getDistanceToEntity(p);
        if (this.isLookedAt(p)) {
            this.lookedTicks++;
            this.getNavigator().clearPathEntity();
            if (this.lookedTicks > 25) { if (!this.tryRush(p)) this.vanish(); return; }
        } else {
            this.lookedTicks = 0;
            if (d > 11.0D) {
                if (this.ticksExisted % 10 == 0) this.getNavigator().tryMoveToEntityLiving(p, 0.8D);
            } else {
                this.getNavigator().clearPathEntity();
            }
        }
        if (d < 20.0D && this.ticksExisted % 60 == 0) {
            this.worldObj.playSound(null, this.posX, this.posY, this.posZ, ModSounds.HEARTBEAT, SoundCategory.HOSTILE, 0.8F, 1.0F);
        }
        if (d < 14.0D && this.ticksExisted % 90 == 0) {
            this.worldObj.playSound(null, this.posX, this.posY, this.posZ, ModSounds.BREATH, SoundCategory.HOSTILE, 0.6F, 0.9F);
        }
        if (d < 6.0D) { this.vanish(); return; }
        if (this.lifeTicks > this.maxLife) {
            if (this.rand.nextFloat() < this.escalateChance) this.setState(NullState.CHASE); else this.vanish();
        }
    }

    // STATE 3: DISTURBANCE - waits in the distance while the director interferes with the world,
    //                        or stands at your door and knocks
    private void tickDisturbance(EntityPlayer p) {
        if (this.doorPos != null) { this.tickDoor(p); return; }
        this.getNavigator().clearPathEntity();
        this.getLookHelper().setLookPositionWithEntity(p, 30.0F, 30.0F);
        if (this.lifeTicks > this.maxLife || this.getDistanceToEntity(p) < 6.0F) this.vanish();
    }

    /**
     * Knock, knock, knock... three rounds of heavy knocks, then: 60% it breaks the door (the door DROPS as an item) and
     * charges; 40% it leaves. If YOU are standing outside, behind it, it turns around, stares, and screams.
     */
    private void tickDoor(EntityPlayer p) {
        this.getNavigator().clearPathEntity();
        if (!(this.worldObj.getBlockState(this.doorPos).getBlock() instanceof BlockDoor)) { this.vanish(); return; }   // you removed the door
        if (this.lifeTicks > this.maxLife) { this.vanish(); return; }

        // where are you? On its side of the door (outside) = it has found you
        double ox = this.posX - (this.doorPos.getX() + 0.5D), oz = this.posZ - (this.doorPos.getZ() + 0.5D);
        double olen = Math.sqrt(ox * ox + oz * oz);
        double side = olen < 0.01D ? -1D : ((p.posX - (this.doorPos.getX() + 0.5D)) * ox + (p.posZ - (this.doorPos.getZ() + 0.5D)) * oz) / olen;
        if (side > 1.2D && this.getDistanceToEntity(p) < 18.0F) {
            this.getLookHelper().setLookPositionWithEntity(p, 60.0F, 60.0F);
            if (this.noticedTicks == 0) {
                this.worldObj.playSound(null, this.posX, this.posY, this.posZ, ModSounds.BREATH, SoundCategory.HOSTILE, 1.8F, 0.55F);
            }
            if (++this.noticedTicks > 30) this.finishWithScare(p);       // it turns, looks at you... and screams
            return;
        }
        this.noticedTicks = 0;

        this.getLookHelper().setLookPosition(this.doorPos.getX() + 0.5D, this.doorPos.getY() + 1.2D, this.doorPos.getZ() + 0.5D, 40.0F, 40.0F);
        if (--this.doorKnockTimer > 0) return;

        if (this.doorKnocks >= 3) {                                     // after the third round it decides
            if (this.rand.nextFloat() < ModConfig.doorBreakChance) this.breakDoorAndCharge();
            else {
                this.worldObj.playSound(null, this.posX, this.posY, this.posZ, ModSounds.CREAK, SoundCategory.HOSTILE, 1.5F, 0.8F);
                this.vanish();
            }
            return;
        }
        this.doorKnocks++;
        this.worldObj.playSound(null, this.doorPos.getX() + 0.5D, this.doorPos.getY() + 1.0D, this.doorPos.getZ() + 0.5D,
                ModSounds.DOOR_KNOCK, SoundCategory.HOSTILE, 3.0F, 1.0F);   // loud: carries far through the house
        this.doorKnockTimer = 100 + this.rand.nextInt(25);               // the knock lasts about 4 seconds
    }

    private void breakDoorAndCharge() {
        BlockPos lower = this.doorPos;
        IBlockState st = this.worldObj.getBlockState(lower);
        if (st.getBlock() instanceof BlockDoor && st.getValue(BlockDoor.HALF) == BlockDoor.EnumDoorHalf.UPPER) lower = lower.down();
        this.worldObj.destroyBlock(lower, true);                        // the door falls to the ground as an item
        this.worldObj.destroyBlock(lower.up(), false);
        this.worldObj.playSound(null, lower.getX() + 0.5D, lower.getY() + 1.0D, lower.getZ() + 0.5D, ModSounds.DOOR_BREAK, SoundCategory.HOSTILE, 3.0F, 1.0F);
        this.worldObj.playSound(null, lower.getX() + 0.5D, lower.getY() + 1.0D, lower.getZ() + 0.5D, ModSounds.STING, SoundCategory.HOSTILE, 1.6F, 0.9F);
        this.darkParticles(30);
        this.doorPos = null;
        this.doorRush = true;
        this.forceRush();
    }

    // STATE 5: CHASE
    private void tickChase(EntityPlayer p) {
        double d = this.getDistanceToEntity(p);
        boolean sees = this.canEntityBeSeen(p);

        // adaptation 1: you start SPRINTING -> it may dash, catch you and scream
        if (this.dashCooldown > 0) this.dashCooldown--;
        if (this.dashing) {
            if (--this.dashTicks <= 0) { this.dashing = false; this.setSpeed(this.chaseSpeed()); }
        } else if (!this.rush && !this.ritual && this.dashCooldown == 0 && sees && d > 4.0D && p.isSprinting() && QuestData.optAdapt(p)
                && this.ticksExisted % 20 == 0 && this.rand.nextFloat() < ModConfig.sprintDashChance + this.pressure * 0.05F) {
            this.dashing = true;
            this.dashTicks = 70;
            this.dashCooldown = 300;
            this.setSpeed(this.chaseSpeed() + 0.14D);
            this.worldObj.playSound(null, this.posX, this.posY, this.posZ, ModSounds.SCRAPE, SoundCategory.HOSTILE, 1.4F, 1.5F);
            this.worldObj.playSound(null, this.posX, this.posY, this.posZ, ModSounds.BREATH, SoundCategory.HOSTILE, 1.4F, 0.5F);
        }

        // adaptation 2: you hide HIGH on blocks -> it builds black blocks up to you
        this.checkTower(p, d);
        if (this.towerMode) return;

        // it broke through your wall: it WATCHES you for 5 seconds, then screams
        if (this.stareTicks > 0) {
            this.getNavigator().clearPathEntity();
            this.getLookHelper().setLookPositionWithEntity(p, 60.0F, 60.0F);
            if (--this.stareTicks == 0) this.finishWithScare(p);
            return;
        }
        if (this.barrierBreaks > 0 && sees && !this.stareDone && d < 16.0D && !this.ritual) {
            this.stareDone = true;
            this.stareTicks = 100;
            this.getNavigator().clearPathEntity();
            this.worldObj.playSound(null, this.posX, this.posY, this.posZ, ModSounds.BREATH, SoundCategory.HOSTILE, 1.8F, 0.5F);
            this.worldObj.playSound(null, this.posX, this.posY, this.posZ, ModSounds.HEARTBEAT, SoundCategory.HOSTILE, 1.4F, 0.8F);
            return;
        }

        // a gap between your block and its block: it LEAPS across and grabs you
        if (this.leapTicks > 0) { this.tickLeap(p); return; }
        double gdy = p.posY - this.posY;
        if (!this.ritual && sees && QuestData.optAdapt(p) && d >= 2.5D && d <= 7.5D && Math.abs(gdy) <= 2.0D
                && this.onGround && this.getNavigator().noPath()) this.gapTicks++; else this.gapTicks = 0;
        if (this.gapTicks >= 30) { this.gapTicks = 0; this.startLeap(p); return; }

        // you walled yourself in (cave or house): it breaks the wall
        if (!sees && d < 14.0D && this.onGround && this.getNavigator().noPath()) this.noPathTicks++; else this.noPathTicks = 0;
        if (this.noPathTicks >= 40 && !this.ritual && QuestData.optAdapt(p)) { this.breakBarrier(p); return; }

        // cunning: sometimes it stops and just STARES, then bursts forward
        if (!this.rush && !this.ritual && !this.dashing) {
            if (this.stallTicks > 0) {
                this.stallTicks--;
                this.getNavigator().clearPathEntity();
                this.getLookHelper().setLookPositionWithEntity(p, 40.0F, 40.0F);
                if (this.stallTicks == 0) {
                    this.burstTicks = 28;
                    this.setSpeed(this.chaseSpeed() + 0.09D);
                    this.worldObj.playSound(null, this.posX, this.posY, this.posZ, ModSounds.SCRAPE, SoundCategory.HOSTILE, 1.0F, 1.4F);
                }
                return;
            }
            if (this.burstTicks > 0 && --this.burstTicks == 0) this.setSpeed(this.chaseSpeed());
            if (this.burstTicks == 0 && sees && d > 7.0D && d < 16.0D && this.ticksExisted % 100 == 0 && this.rand.nextFloat() < 0.4F + this.adapt * 0.3F) {
                this.stallTicks = 18;
            }
        }

        // hearing: sprinting or mining near it gives your position away - sneaking makes it lose you
        if (!sees && d < 18.0D && this.ticksExisted % 20 == 0 && !p.isSneaking() && (p.isSprinting() || p.isSwingInProgress)) {
            this.lastKnown = new BlockPos(p);
            this.searchTicks = 0;
        }
        if (sees) {
            this.lastKnown = new BlockPos(p);
            this.searchTicks = 0;
            this.getLookHelper().setLookPositionWithEntity(p, 40.0F, 40.0F);
            if (this.ticksExisted % (this.dashing ? 4 : 8) == 0) this.pursue(p, d);
        } else if (this.lastKnown != null) {
            if (this.ticksExisted % 10 == 0) {
                this.getNavigator().tryMoveToXYZ(this.lastKnown.getX() + 0.5D, this.lastKnown.getY(), this.lastKnown.getZ() + 0.5D, 1.0D);
            }
            if (this.getDistanceSq(this.lastKnown) < 6.0D) this.searchTicks++;
            if (p.isSneaking()) this.searchTicks++;
        } else {
            this.searchTicks++;
        }
        if (this.searchTicks > 120 && !this.ritual) { this.vanish(); return; }

        if (sees && d < 1.9D && this.attackCooldown <= 0) this.onCatch(p);
        if (this.ticksExisted % 11 == 0) {
            this.worldObj.playSound(null, this.posX, this.posY, this.posZ, ModSounds.CHASE_STEP, SoundCategory.HOSTILE, 1.0F, 0.9F + this.rand.nextFloat() * 0.2F);
        }
        if (d < 18.0D && this.ticksExisted % 40 == 0) {
            this.worldObj.playSound(null, this.posX, this.posY, this.posZ, ModSounds.HEARTBEAT, SoundCategory.HOSTILE, 0.9F, 1.15F);
        }
        if (this.getState() == NullState.CHASE && !this.ritual) {
            this.chaseTicksLeft--;
            if (this.chaseTicksLeft <= 0 || d > 56.0D) {
                QuestManager.onChaseSurvived(p);
                this.vanish();
            }
        }
    }

    // ---- leap, barrier, scare finisher ---------------------------------------------------
    private void startLeap(EntityPlayer p) {
        double dx = p.posX - this.posX, dz = p.posZ - this.posZ, len = Math.sqrt(dx * dx + dz * dz);
        if (len < 0.01D) return;
        this.leapFrom = new Vec3d(this.posX, this.posY, this.posZ);
        this.leapTo = new Vec3d(p.posX - dx / len * 1.1D, p.posY, p.posZ - dz / len * 1.1D);
        this.leapTicks = 11;
        this.getNavigator().clearPathEntity();
        this.worldObj.playSound(null, this.posX, this.posY, this.posZ, ModSounds.SCRAPE, SoundCategory.HOSTILE, 1.6F, 1.6F);
        this.worldObj.playSound(null, this.posX, this.posY, this.posZ, ModSounds.BREATH, SoundCategory.HOSTILE, 1.6F, 0.5F);
    }

    /** A fast arc over the gap (it does not need a path), ending in the scare. */
    private void tickLeap(EntityPlayer p) {
        double f = (12 - this.leapTicks) / 11.0D;
        double x = this.leapFrom.xCoord + (this.leapTo.xCoord - this.leapFrom.xCoord) * f;
        double z = this.leapFrom.zCoord + (this.leapTo.zCoord - this.leapFrom.zCoord) * f;
        double y = this.leapFrom.yCoord + (this.leapTo.yCoord - this.leapFrom.yCoord) * f + 1.7D * Math.sin(Math.PI * f);
        this.setPositionAndUpdate(x, y, z);
        this.fallDistance = 0.0F;
        this.getLookHelper().setLookPositionWithEntity(p, 60.0F, 60.0F);
        this.darkParticles(2);
        if (--this.leapTicks <= 0) this.finishWithScare(p);
    }

    /** Breaks the block that stands between it and you (at most 5 blocks per hunt, never unbreakable ones). */
    private void breakBarrier(EntityPlayer p) {
        Vec3d eye = new Vec3d(this.posX, this.posY + this.getEyeHeight(), this.posZ);
        Vec3d target = new Vec3d(p.posX, p.posY + p.getEyeHeight(), p.posZ);
        RayTraceResult rt = this.worldObj.rayTraceBlocks(eye, target, false, true, false);
        if (rt == null) { this.noPathTicks = 0; return; }                     // clear line: nothing to break
        if (rt.typeOfHit != RayTraceResult.Type.BLOCK) return;
        if (--this.breakTimer > 0) return;
        this.breakTimer = 10;
        if (this.barrierBreaks >= 5) { this.vanish(); return; }                // too thick: it gives up
        BlockPos bp = rt.getBlockPos();
        IBlockState st = this.worldObj.getBlockState(bp);
        if (st.getBlockHardness(this.worldObj, bp) < 0.0F || st.getBlock() == ModBlocks.ancientAltar) { this.vanish(); return; }
        this.worldObj.destroyBlock(bp, false);
        this.barrierBreaks++;
        this.worldObj.playSound(null, bp.getX() + 0.5D, bp.getY() + 0.5D, bp.getZ() + 0.5D, ModSounds.SCRAPE, SoundCategory.HOSTILE, 1.5F, 0.7F);
        this.darkParticles(10);
    }

    /** Jumpscare (or a hit when jumpscares are switched off) and gone. */
    private void finishWithScare(EntityPlayer p) {
        this.leapTicks = 0;
        if (p instanceof EntityPlayerMP && QuestData.optJump(p)) {
            Jumpscare.fire((EntityPlayerMP) p, HorrorDirector.rec(p), this.rand.nextInt(3));
            QuestManager.onChaseSurvived(p);
            this.vanish();
        } else {
            this.swingArm(EnumHand.MAIN_HAND);
            float dmg = (float) this.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).getAttributeValue();
            p.attackEntityFrom(DamageSource.causeMobDamage(this), dmg);
            this.attackCooldown = 20;
            this.vanish();
        }
    }

    /** Heads for where you WILL be (current position + your velocity), not where you are. */
    private void pursue(EntityPlayer p, double d) {
        double speed = Math.sqrt(this.velX * this.velX + this.velZ * this.velZ);
        if (d > 6.0D && speed > 0.05D) {
            double lead = Math.min(30.0D, d * 2.0D);
            if (this.getNavigator().tryMoveToXYZ(p.posX + this.velX * lead, p.posY, p.posZ + this.velZ * lead, 1.0D)) return;
        }
        this.getNavigator().tryMoveToEntityLiving(p, 1.0D);
    }

    // ---- tower hunting --------------------------------------------------------------------
    /** You are 3+ blocks above it, close by, and it has no path to you: after 3 seconds it starts building. */
    private void checkTower(EntityPlayer p, double d) {
        if (!QuestData.optAdapt(p)) { this.towerMode = false; return; }
        double dy = p.posY - this.posY;
        double dx = p.posX - this.posX, dz = p.posZ - this.posZ;
        double dh = Math.sqrt(dx * dx + dz * dz);
        if (this.ticksExisted % 20 == 0) {
            boolean stranded = dy >= 2.5D && dh <= 8.0D && this.onGround && this.getNavigator().noPath();
            if (stranded) this.towerTicks++; else if (!this.towerMode) this.towerTicks = Math.max(0, this.towerTicks - 1);
        }
        if (!this.towerMode && this.towerTicks >= 3 && !this.ritual) {
            this.towerMode = true;
            this.towerBuildTimer = 10;
            this.towerFails = 0;
            this.getNavigator().clearPathEntity();
            this.worldObj.playSound(null, this.posX, this.posY, this.posZ, ModSounds.STING, SoundCategory.HOSTILE, 1.2F, 0.7F);
            this.worldObj.playSound(null, this.posX, this.posY, this.posZ, ModSounds.WHISPER, SoundCategory.HOSTILE, 1.4F, 0.8F);
        }
        if (!this.towerMode) return;
        if (dy < 1.2D) { this.towerMode = false; this.towerTicks = 0; return; }              // you came down
        this.getLookHelper().setLookPositionWithEntity(p, 40.0F, 40.0F);
        if (--this.towerBuildTimer <= 0) {
            this.towerBuildTimer = 14;
            this.buildStep(p, dh, dy);
        }
    }

    private void buildStep(EntityPlayer p, double dh, double dy) {
        if (!(this.worldObj instanceof WorldServer)) return;
        WorldServer w = (WorldServer) this.worldObj;
        BlockPos feet = new BlockPos(this.posX, this.posY, this.posZ);

        BlockPos target = null;
        if (dh < 2.5D) {
            target = feet;                                              // right under you: build straight up
        } else {
            double ax = Math.abs(p.posX - this.posX), az = Math.abs(p.posZ - this.posZ);
            EnumFacing primary = ax >= az ? (p.posX >= this.posX ? EnumFacing.EAST : EnumFacing.WEST) : (p.posZ >= this.posZ ? EnumFacing.SOUTH : EnumFacing.NORTH);
            EnumFacing secondary = ax >= az ? (p.posZ >= this.posZ ? EnumFacing.SOUTH : EnumFacing.NORTH) : (p.posX >= this.posX ? EnumFacing.EAST : EnumFacing.WEST);
            EnumFacing[] order = { primary, secondary, primary.getOpposite() };
            for (EnumFacing f : order) {
                BlockPos cand = feet.offset(f);
                if (w.isAirBlock(cand) && w.isAirBlock(cand.up()) && w.isAirBlock(cand.up(2))) { target = cand; break; }
            }
        }
        if (target == null || !w.isAirBlock(target.up()) || !w.isAirBlock(target.up(2))) {
            if (++this.towerFails >= 4) this.vanish();                  // nowhere to build: it gives up
            return;
        }
        NullBlocks.place(w, target);
        this.setPositionAndUpdate(target.getX() + 0.5D, target.getY() + 1.0D, target.getZ() + 0.5D);   // climbs its own black stair
        this.towerFails = 0;
        this.darkParticles(8);

        double ndy = p.posY - this.posY;
        double ndx = p.posX - this.posX, ndz = p.posZ - this.posZ;
        if (ndy < 1.8D && Math.sqrt(ndx * ndx + ndz * ndz) < 3.2D && !this.towerResolved) {
            this.towerResolved = true;
            this.onTowerReached(p);
        }
    }

    /** It reached you: 50% a jumpscare, otherwise it hits you and the hunt goes on. */
    private void onTowerReached(EntityPlayer p) {
        boolean scare = p instanceof EntityPlayerMP && QuestData.optJump(p) && this.rand.nextFloat() < ModConfig.towerScareChance;
        this.towerMode = false;
        this.towerTicks = 0;
        if (scare) {
            Jumpscare.fire((EntityPlayerMP) p, HorrorDirector.rec(p), this.rand.nextInt(3));
            QuestManager.onChaseSurvived(p);
            this.vanish();
        } else {
            this.swingArm(EnumHand.MAIN_HAND);
            float dmg = (float) this.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).getAttributeValue();
            p.attackEntityFrom(DamageSource.causeMobDamage(this), dmg);
            this.attackCooldown = 20;
            this.worldObj.playSound(null, this.posX, this.posY, this.posZ, ModSounds.STING, SoundCategory.HOSTILE, 1.0F, 1.0F);
        }
    }

    /** The Null reached you. Outcome: lethal hit, jumpscare, or a normal hit (the ritual is never lethal). */
    private void onCatch(EntityPlayer p) {
        this.attackCooldown = 20;
        this.swingArm(EnumHand.MAIN_HAND);
        float kill, scare;
        if (this.ritual) { kill = 0F; scare = 0F; }
        else if (this.doorRush || this.dashing) { kill = 0F; scare = 1F; }                // broke in / dashed: always a scream
        else if (this.rush) { kill = ModConfig.rushKillChance; scare = 1F - kill; }
        else { kill = ModConfig.chaseKillChance + this.threat * 0.02F + this.pressure * 0.03F; scare = ModConfig.chaseScareChance; }
        if (QuestData.getStage(p) == 0) kill = 0F;                                       // the first encounter is never lethal
        if (!QuestData.optJump(p) || !(p instanceof EntityPlayerMP)) scare = 0F;
        float roll = this.rand.nextFloat();
        if (roll < kill) {
            p.attackEntityFrom(DamageSource.causeMobDamage(this), 1000.0F);
            this.vanish();
        } else if (roll < kill + scare) {
            Jumpscare.fire((EntityPlayerMP) p, HorrorDirector.rec(p), this.rand.nextInt(3));
            QuestManager.onChaseSurvived(p);
            this.vanish();
        } else {
            float dmg = (float) this.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).getAttributeValue();
            p.attackEntityFrom(DamageSource.causeMobDamage(this), dmg);
        }
    }

    // STATE 6: VANISHING
    public void vanish() {
        if (this.worldObj.isRemote || this.getState() == NullState.VANISHING) return;
        this.setState(NullState.VANISHING);
        this.getNavigator().clearPathEntity();
        if (this.ownerId != null) {
            EntityPlayer o = this.worldObj.getPlayerEntityByUUID(this.ownerId);
            if (o instanceof EntityPlayerMP) NetworkHandler.CHANNEL.sendTo(new PacketFx(PacketFx.CHASE_DIST, -1F), (EntityPlayerMP) o);
        }
        this.worldObj.playSound(null, this.posX, this.posY, this.posZ, ModSounds.VANISH, SoundCategory.HOSTILE, 1.0F, 1.0F);
        this.darkParticles(25);
    }

    /** Final sealing: lifts the ritual lock, then vanishes with extra smoke. */
    public void sealAway() {
        this.ritual = false;
        this.rush = false;
        this.vanish();
        this.darkParticles(60);
    }

    private void darkParticles(int n) {
        if (this.worldObj instanceof WorldServer) {
            ((WorldServer) this.worldObj).spawnParticle(EnumParticleTypes.SMOKE_LARGE, this.posX, this.posY + 1.0D, this.posZ, n, 0.3D, 0.8D, 0.3D, 0.02D);
        }
    }

    private boolean isLookedAt(EntityPlayer p) {
        Vec3d look = p.getLook(1.0F).normalize();
        Vec3d to = new Vec3d(this.posX - p.posX, (this.posY + this.getEyeHeight()) - (p.posY + p.getEyeHeight()), this.posZ - p.posZ);
        if (to.lengthVector() < 0.001D) return true;
        return look.dotProduct(to.normalize()) > 0.93D && p.canEntityBeSeen(this);
    }

    @Override
    public boolean attackEntityFrom(DamageSource src, float amount) {
        if (src == DamageSource.outOfWorld) return super.attackEntityFrom(src, amount);
        NullState st = this.getState();
        if (!this.worldObj.isRemote && src.getEntity() instanceof EntityPlayer
                && (st == NullState.OBSERVING || st == NullState.STALKING || st == NullState.DISTURBANCE)) {
            this.vanish();      // cannot be killed - it just leaves
        }
        return false;
    }
}
