package com.spoiledseed.horror;

import com.spoiledseed.registry.ModSounds;
import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.WorldServer;

/** When you come out of a cave after a while, a line of redstone dust lies on the ground ahead of you: it was here. */
public class CaveTrail {
    private static final Random RAND = new Random();

    public static int place(EntityPlayerMP p) {
        WorldServer w = (WorldServer) p.worldObj;
        BlockPos base = new BlockPos(p);
        Vec3d look = p.getLookVec();
        double dx = look.xCoord, dz = look.zCoord, len = Math.sqrt(dx * dx + dz * dz);
        if (len < 0.2D) { double a = RAND.nextDouble() * Math.PI * 2D; dx = Math.cos(a); dz = Math.sin(a); len = 1D; }
        dx /= len; dz /= len;

        int placed = 0;
        for (int i = 3; i <= 14 && placed < 7; i++) {
            BlockPos probe = new BlockPos(base.getX() + (int) Math.round(dx * i), 64, base.getZ() + (int) Math.round(dz * i));
            if (!w.isBlockLoaded(probe)) continue;
            BlockPos g = w.getHeight(probe);
            while (g.getY() > 1 && (w.isAirBlock(g.down()) || isFoliage(w, g.down()))) g = g.down();
            if (Math.abs(g.getY() - base.getY()) > 4) continue;
            if (w.isAirBlock(g) && w.getBlockState(g.down()).isOpaqueCube()) {
                w.setBlockState(g, Blocks.REDSTONE_WIRE.getDefaultState());
                placed++;
            }
        }
        if (placed > 0) {
            w.playSound(null, p.posX, p.posY, p.posZ, ModSounds.STING, SoundCategory.HOSTILE, 0.5F, 0.6F);
        }
        return placed;
    }

    private static boolean isFoliage(WorldServer w, BlockPos pos) {
        Material m = w.getBlockState(pos).getMaterial();
        return m == Material.LEAVES || m == Material.PLANTS || m == Material.VINE;
    }
}
