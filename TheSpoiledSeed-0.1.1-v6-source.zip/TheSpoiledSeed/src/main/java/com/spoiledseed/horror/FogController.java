package com.spoiledseed.horror;

import com.spoiledseed.config.ModConfig;
import com.spoiledseed.entity.EntityNull;
import com.spoiledseed.network.NetworkHandler;
import com.spoiledseed.network.PacketFx;
import com.spoiledseed.quest.QuestData;
import java.util.Random;
import net.minecraft.entity.player.EntityPlayerMP;

/**
 * The Black Fog is part of the world, not of the monster:
 *  - a constant baseline from the moment you spawn (heavier at night),
 *  - natural thicker episodes, fog before encounters and after scares,
 *  - thicker when The Null is near.
 * The player can switch all of it off in Mod Options.
 */
public class FogController {
    private static final Random RAND = new Random();

    public static void second(EntityPlayerMP p, PlayerHorror r, EntityNull n, float intensity, boolean night) {
        boolean on = ModConfig.fogEnabled && QuestData.optFog(p);
        float fog = on ? ModConfig.fogBaseline * (night ? 1.5F : 1F) : 0F;
        float prelude = r.fogPrelude;
        r.fogPrelude = Math.max(0F, r.fogPrelude - 0.05F);

        if (on) {
            fog = Math.max(fog, prelude);
            if (r.episodeLeft > 0) {
                r.episodeLeft--;
                fog = Math.max(fog, r.episodeLevel);
            } else if (RAND.nextFloat() < ModConfig.fogEpisodeChance * (1F + 2F * intensity)) {
                r.episodeLeft = 60 + RAND.nextInt(100);                 // 1 - 2.7 minutes
                r.episodeLevel = 0.25F + RAND.nextFloat() * 0.45F;
            }
            if (n != null) {
                float d = (float) n.getDistanceToEntity(p);
                fog = Math.max(fog, 0.25F + 0.75F * Math.max(0F, 1F - d / 45F));
            }
        }
        fog *= QuestData.optFogStrength(p) / 100F;                       // the player's own fog strength
        if (r.fogForce >= 0F) fog = r.fogForce;                          // /ss fog <n>
        send(p, r, fog);
    }

    public static void send(EntityPlayerMP p, PlayerHorror r, float f) {
        f = Math.max(0F, Math.min(1F, f));
        if (Math.abs(f - r.lastFogSent) > 0.03F) {
            r.lastFogSent = f;
            NetworkHandler.CHANNEL.sendTo(new PacketFx(PacketFx.FOG, f), p);
        }
    }

    public static void sendNow(EntityPlayerMP p, PlayerHorror r, float f) {
        r.lastFogSent = -1F;
        send(p, r, f);
    }
}
