package com.spoiledseed.horror;

import com.spoiledseed.quest.QuestData;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;

/**
 * Remembers WHERE the player spends time (up to 8 zones, 24-block radius, saved with the player).
 * A zone with weight >= 6 (about 3 minutes spent there) counts as "home": it haunts that place like your bed.
 */
public class ZoneTracker {
    private static final String KEY = "Zones";
    private static final int RADIUS = 24;
    public static final int HOME_WEIGHT = 6;

    private static NBTTagList list(EntityPlayerMP p) {
        return QuestData.get(p).getTagList(KEY, 10);
    }

    /** Called every 30 seconds. */
    public static void sample(EntityPlayerMP p) {
        NBTTagList zones = list(p);
        int best = -1;
        double bestD = (double) RADIUS * RADIUS;
        for (int i = 0; i < zones.tagCount(); i++) {
            NBTTagCompound z = zones.getCompoundTagAt(i);
            double dx = p.posX - z.getInteger("x"), dy = p.posY - z.getInteger("y"), dz = p.posZ - z.getInteger("z");
            double d = dx * dx + dy * dy + dz * dz;
            if (d <= bestD) { bestD = d; best = i; }
        }
        if (best >= 0) {
            NBTTagCompound z = zones.getCompoundTagAt(best);
            z.setInteger("w", Math.min(400, z.getInteger("w") + 1));
        } else {
            if (zones.tagCount() >= 8) {                               // forget the least visited zone
                int low = 0;
                for (int i = 1; i < zones.tagCount(); i++) if (zones.getCompoundTagAt(i).getInteger("w") < zones.getCompoundTagAt(low).getInteger("w")) low = i;
                zones.removeTag(low);
            }
            NBTTagCompound z = new NBTTagCompound();
            z.setInteger("x", (int) p.posX);
            z.setInteger("y", (int) p.posY);
            z.setInteger("z", (int) p.posZ);
            z.setInteger("w", 1);
            zones.appendTag(z);
        }
        QuestData.get(p).setTag(KEY, zones);
    }

    /** Weight of the zone the player is in right now (0 = a place never visited before). */
    public static int weightHere(EntityPlayerMP p) {
        NBTTagList zones = list(p);
        for (int i = 0; i < zones.tagCount(); i++) {
            NBTTagCompound z = zones.getCompoundTagAt(i);
            double dx = p.posX - z.getInteger("x"), dy = p.posY - z.getInteger("y"), dz = p.posZ - z.getInteger("z");
            if (dx * dx + dy * dy + dz * dz <= (double) RADIUS * RADIUS) return z.getInteger("w");
        }
        return 0;
    }
}
