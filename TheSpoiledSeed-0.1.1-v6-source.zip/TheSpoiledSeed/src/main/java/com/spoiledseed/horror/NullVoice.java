package com.spoiledseed.horror;

import com.spoiledseed.quest.QuestData;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.WorldServer;

/**
 * Everything The Null says. Chat lines always come from "Null". The lines are short, quiet and PERSONAL:
 * it knows your name, where you stand, what you hold, how many torches you have, how hurt you are,
 * where you sleep - and who else is on the server.
 */
public class NullVoice {
    private static final Random RAND = new Random();

    private static final String[] GENERIC = {
        "{name}.", "{name}. Don't turn around.", "Stop. Listen. Do you hear it breathing?", "I have been standing behind you for a while.",
        "You looked right at me. You didn't see me.", "It's okay to be afraid.", "You keep walking away. I keep being there.",
        "Why did you stop running?", "Don't scream. It likes that.", "I was in the corner of your room.",
        "Look at your hands. Look at your feet. Now look behind you.", "You are never really alone in the fog.",
        "I never sleep.", "The sky looks wrong tonight, doesn't it?", "I know the sound your footsteps make.",
        "I counted your breaths. You are breathing faster now."
    };
    private static final String[] BED = {
        "I know where you sleep.", "I stood beside your bed while your eyes were closed.", "Your bed is still warm where I lay.",
        "You sleep with your back to the door. I noticed.", "When you wake, I'll be the last thing you see.",
        "Your pillow remembers me."
    };
    private static final String[] HOME = {
        "I was inside your house.", "I touched every chest in your home.", "The walls will not hold. You know that.",
        "Check your doors, {name}. All of them. Tonight.", "I know every room you built.", "I know which window you forgot."
    };
    private static final String[] NIGHT = {
        "The dark is not empty.", "Do not go outside tonight.", "Moonlight does not reach where I am standing.",
        "I am awake. Are you?", "Night is when I stop pretending."
    };
    private static final String[] UNDER = {
        "You are very far from the sky.", "I heard your pickaxe from here.", "There is something in the tunnel behind you.",
        "The dark down here was mine long before you came.", "Nobody will hear you this deep.", "Stop digging."
    };
    private static final String[] RELIC = {
        "You carry something of mine.", "Put it back, {name}.", "I can feel it in your pocket.",
        "A little seal will not hold me. You know that.", "Bring it to me and I will make it quick."
    };
    private static final String[] LOWHP = {
        "You're hurt. I can smell it.", "Your heart is so loud right now.", "You won't survive another one of me."
    };
    private static final String[] TORCHES = {
        "You carry {torches} torches. Lights go out, {name}.", "{torches} torches. It won't be enough."
    };
    private static final String[] HELD = {
        "That {item} will not save you.", "You hold your {item} so tightly.", "Put the {item} down. You'll need your hands."
    };
    private static final String[] COORD = {
        "You are standing at {x}, {y}, {z}. I am closer than that.", "{x} {y} {z}. Remember where you stood.",
        "I know exactly where you are: {x}, {y}, {z}."
    };
    private static final String[] OTHER = {
        "{other} doesn't know I'm here yet.", "I walked past {other}. They didn't see me.", "{other} will not notice when I take you.",
        "{other} can't hear me. Only you can.", "I'm standing very close to {other} right now."
    };

    /** A line that fits the player's situation. */
    public static String line(EntityPlayerMP p) {
        List<String[]> pools = new ArrayList<String[]>();
        pools.add(GENERIC);
        pools.add(GENERIC);
        if (p.getBedLocation() != null) pools.add(BED);
        if (HorrorDirector.isNearHome(p)) { pools.add(HOME); pools.add(HOME); }
        if (HorrorDirector.isNight((WorldServer) p.worldObj)) pools.add(NIGHT);
        if (HorrorDirector.isUnderground(p)) { pools.add(UNDER); pools.add(UNDER); }
        if (QuestData.getThreat(p) >= 6) { pools.add(RELIC); pools.add(RELIC); }
        if (p.getHealth() < 8.0F) { pools.add(LOWHP); pools.add(LOWHP); }
        if (torches(p) > 0) pools.add(TORCHES);
        if (p.getHeldItemMainhand() != null) pools.add(HELD);
        pools.add(COORD);
        String other = otherPlayer(p);
        if (other != null) { pools.add(OTHER); pools.add(OTHER); pools.add(OTHER); }   // multiplayer: it talks about the others

        String[] pool = pools.get(RAND.nextInt(pools.size()));
        String t = pool[RAND.nextInt(pool.length)];
        ItemStack held = p.getHeldItemMainhand();
        return t.replace("{name}", p.getName())
                .replace("{other}", other == null ? "someone" : other)
                .replace("{torches}", String.valueOf(torches(p)))
                .replace("{item}", held == null ? "hands" : held.getDisplayName())
                .replace("{x}", String.valueOf((int) p.posX)).replace("{y}", String.valueOf((int) p.posY)).replace("{z}", String.valueOf((int) p.posZ));
    }

    private static int torches(EntityPlayerMP p) {
        Item torch = Item.getItemFromBlock(Blocks.TORCH);
        int n = 0;
        for (ItemStack s : p.inventory.mainInventory) if (s != null && s.getItem() == torch) n += s.stackSize;
        return n;
    }

    /** Another online player (multiplayer), or null. */
    public static String otherPlayer(EntityPlayerMP p) {
        MinecraftServer s = p.getServer();
        if (s == null) return null;
        List<String> names = new ArrayList<String>();
        for (EntityPlayerMP q : s.getPlayerList().getPlayerList()) if (q != p) names.add(q.getName());
        return names.isEmpty() ? null : names.get(RAND.nextInt(names.size()));
    }

    public static ITextComponent format(String text) {
        return new TextComponentString(TextFormatting.WHITE + "<" + TextFormatting.DARK_RED + "Null" + TextFormatting.WHITE + "> "
                + TextFormatting.GRAY + text);
    }

    public static void say(EntityPlayerMP p, String text) { p.addChatMessage(format(text)); }

    public static void say(EntityPlayerMP p) { say(p, line(p)); }

    /** To everybody online. */
    public static void broadcast(MinecraftServer server, String text) {
        if (server == null) return;
        ITextComponent c = format(text);
        for (EntityPlayerMP q : server.getPlayerList().getPlayerList()) q.addChatMessage(c);
    }

    // ---- signs: 4 lines of at most 15 characters ----
    private static final String[][] SIGNS = {
        { "I KNOW WHERE", "YOU SLEEP", "", "" },
        { "DONT TURN", "AROUND", "", "" },
        { "IT IS BEHIND", "YOU NOW", "", "" },
        { "YOU CANNOT", "HIDE", "", "" },
        { "I WAS IN", "YOUR HOUSE", "", "" },
        { "WHY DID YOU", "STOP RUNNING", "", "" },
        { "THE FOG", "BELONGS TO", "ME", "" },
        { "DONT LOOK UP", "", "", "" },
        { "I AM STILL", "HERE", "", "" },
        { "I HEARD YOU", "BREATHING", "", "" },
        { "I WILL OPEN", "YOUR DOOR", "", "" },
        { "NOBODY", "WILL COME", "", "" },
        { "DO NOT", "BREAK THIS", "", "" },
        { "I SEE YOU", "FROM THE", "TREES", "" },
        { "RUN", "", "", "" }
    };

    public static String[] signLines(EntityPlayerMP p) {
        int roll = RAND.nextInt(5);
        if (roll == 0) {                                              // personal sign
            String n = p.getName().toUpperCase();
            if (n.length() > 15) n = n.substring(0, 15);
            return new String[] { n, "I SEE YOU", "", "" };
        }
        if (roll == 1 && HorrorDirector.isUnderground(p)) return new String[] { "NOBODY HEARS", "YOU DOWN HERE", "", "" };
        if (roll == 2 && QuestData.getThreat(p) >= 6) return new String[] { "PUT IT BACK", "", "", "" };
        return SIGNS[RAND.nextInt(SIGNS.length)];
    }
}
