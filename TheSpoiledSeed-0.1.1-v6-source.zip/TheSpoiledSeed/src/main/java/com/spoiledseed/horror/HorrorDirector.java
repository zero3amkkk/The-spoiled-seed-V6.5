package com.spoiledseed.horror;

import com.spoiledseed.config.ModConfig;
import com.spoiledseed.entity.EntityNull;
import com.spoiledseed.entity.NullState;
import com.spoiledseed.network.NetworkHandler;
import com.spoiledseed.network.PacketFx;
import com.spoiledseed.quest.FinalRitual;
import com.spoiledseed.quest.QuestData;
import com.spoiledseed.guide.GuideBook;
import com.spoiledseed.guide.GuideHandler;
import com.spoiledseed.quest.QuestManager;
import com.spoiledseed.registry.ModSounds;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.WorldServer;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;

/**
 * Decides WHEN things happen to each player (once per second).
 * Pressure comes from: play time and in-game DAYS (they never stop growing), quest stage, THREAT (ritual items found),
 * NIGHT, being near HOME (bed, spawn, or a place where you spend a lot of time), and - in multiplayer - being the
 * player The Null has "marked". The player's Mod Options are respected.
 */
public class HorrorDirector {
    public static final Random RAND = new Random();
    private static final Map<UUID, PlayerHorror> PLAYERS = new HashMap<UUID, PlayerHorror>();
    private static final float[] LEVEL_MULT = { 0.5F, 1.0F, 1.6F };
    /** Heavy events: after one of these, the next two are always calm ones (a fear curve, not pure randomness). */
    private static final EnumSet<HorrorEvent> BIG = EnumSet.of(HorrorEvent.CHASE, HorrorEvent.CAVECHASE, HorrorEvent.JUMPSCARE,
            HorrorEvent.DOORKNOCK, HorrorEvent.STALK, HorrorEvent.BLACKOUT);

    // multiplayer: one player at a time is "marked" and hunted harder
    private static UUID marked;
    private static int markedLeft;
    private static int markCooldown = 600;
    private static int tickCounter;

    public static PlayerHorror rec(EntityPlayer p) {
        PlayerHorror r = PLAYERS.get(p.getUniqueID());
        if (r == null) { r = new PlayerHorror(); PLAYERS.put(p.getUniqueID(), r); }
        return r;
    }

    public static void reset() {
        PLAYERS.clear();
        Scheduler.clear();
        NullBlocks.clear();
        NullTab.reset();
        FinalRitual.clearAll();
        marked = null;
        markedLeft = 0;
        markCooldown = 600;
    }

    public static void msg(EntityPlayer p, String s) {
        p.addChatMessage(new TextComponentString(TextFormatting.DARK_GRAY + "" + TextFormatting.ITALIC + s));
    }

    public static void sendOptions(EntityPlayerMP p) {
        NetworkHandler.CHANNEL.sendTo(new PacketFx(PacketFx.OPTIONS, QuestData.optMask(p)), p);
    }

    public static void sendStats(EntityPlayerMP p) {
        NetworkHandler.CHANNEL.sendTo(new PacketFx(PacketFx.STATS, QuestData.getStage(p) + 16 * QuestData.getThreat(p),
                QuestData.getSeconds(p) / 60F), p);
    }

    // ---- world context --------------------------------------------------------------------
    public static boolean isNight(WorldServer w) {
        long t = w.getWorldTime() % 24000L;
        return t >= 13000L && t <= 23000L;
    }

    /** Your bed, the world spawn, or a place where you have spent a lot of time. */
    public static boolean isNearHome(EntityPlayerMP p) {
        WorldServer w = (WorldServer) p.worldObj;
        BlockPos home = p.getBedLocation();
        if (home == null) home = w.getSpawnPoint();
        double dx = p.posX - home.getX(), dz = p.posZ - home.getZ();
        if (dx * dx + dz * dz <= (double) ModConfig.homeRadius * ModConfig.homeRadius) return true;
        return ZoneTracker.weightHere(p) >= ZoneTracker.HOME_WEIGHT;
    }

    public static boolean isUnderground(EntityPlayerMP p) {
        return p.posY < 55D && !p.worldObj.canSeeSky(new BlockPos(p));
    }

    /** 0..2: grows with every in-game day and every hour of play. It never goes down. */
    public static float pressure(EntityPlayer p) {
        if (!QuestData.optTime(p)) return 0F;
        float days = p.worldObj.getTotalWorldTime() / 24000F;
        float hours = QuestData.getSeconds(p) / 3600F;
        return Math.min(2F, days * 0.05F + hours * 0.15F);
    }

    // ---- Forge events ---------------------------------------------------------------------
    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.side != Side.SERVER || !(e.player instanceof EntityPlayerMP)) return;
        if (e.player.ticksExisted % 20 != 0) return;
        try {
            secondTick((EntityPlayerMP) e.player);
        } catch (RuntimeException ex) {
            ex.printStackTrace();           // a horror bug must never crash the server
        }
    }

    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        tickCounter++;
        Scheduler.tick();
        WorldPranks.tick();
        NullBlocks.tick(tickCounter);
        if (tickCounter % 20 == 0) {
            try { markTick(); } catch (RuntimeException ex) { ex.printStackTrace(); }
        }
    }

    @SubscribeEvent
    public void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (!(e.player instanceof EntityPlayerMP)) return;
        final EntityPlayerMP p = (EntityPlayerMP) e.player;
        Scheduler.schedule(60, new Runnable() {                                  // late joiners get "Null" in their tab list
            @Override public void run() {
                MinecraftServer s = p.getServer();
                if (s != null && NullTab.isOnline() && !p.isDead) NullTab.add(s, (WorldServer) p.worldObj);
            }
        });
    }

    @SubscribeEvent
    public void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (e.player instanceof EntityPlayerMP) FinalRitual.cancel((EntityPlayerMP) e.player, null);
        PLAYERS.remove(e.player.getUniqueID());
        if (e.player.getUniqueID().equals(marked)) { marked = null; markedLeft = 0; }
    }

    @SubscribeEvent
    public void onDeath(LivingDeathEvent e) {
        if (!(e.getEntityLiving() instanceof EntityPlayerMP)) return;
        EntityPlayerMP p = (EntityPlayerMP) e.getEntityLiving();
        FinalRitual.cancel(p, "The altar goes dark.");
        PlayerHorror r = PLAYERS.get(p.getUniqueID());
        if (r != null) { r.pending = null; r.cooldown = Math.max(r.cooldown, 60); r.adapt *= 0.5F; }

        // multiplayer: everyone on the server learns who it took
        if (e.getSource() != null && e.getSource().getEntity() instanceof EntityNull) {
            MinecraftServer server = p.getServer();
            NullVoice.broadcast(server, p.getName() + " was mine.");
            if (server != null) {
                for (EntityPlayerMP q : server.getPlayerList().getPlayerList()) {
                    if (q == p) continue;
                    q.worldObj.playSound(null, q.posX, q.posY, q.posZ, ModSounds.HEARTBEAT, SoundCategory.HOSTILE, 1.3F, 0.8F);
                    rec(q).fogPrelude = Math.max(rec(q).fogPrelude, 0.8F);
                }
            }
        }
    }

    // ---- multiplayer: the marked player ---------------------------------------------------------
    private void markTick() {
        MinecraftServer server = FMLCommonHandler.instance().getMinecraftServerInstance();
        if (server == null) return;
        if (markedLeft > 0 && --markedLeft == 0) marked = null;
        List<EntityPlayerMP> eligible = new ArrayList<EntityPlayerMP>();
        for (EntityPlayerMP q : server.getPlayerList().getPlayerList()) {
            if (q.dimension == 0 && QuestData.optMark(q) && !QuestData.isSealed(q) && !q.capabilities.isCreativeMode && !q.isSpectator()) eligible.add(q);
        }
        if (eligible.size() < 2) { marked = null; markedLeft = 0; return; }       // needs company to pick from
        if (--markCooldown > 0) return;
        markCooldown = 900 + RAND.nextInt(600);
        EntityPlayerMP victim = eligible.get(RAND.nextInt(eligible.size()));
        marked = victim.getUniqueID();
        markedLeft = 600;
        NullVoice.broadcast(server, "I am watching " + victim.getName() + " tonight.");
        victim.worldObj.playSound(null, victim.posX, victim.posY, victim.posZ, ModSounds.STING, SoundCategory.HOSTILE, 1.0F, 0.7F);
        rec(victim).cooldown = Math.min(rec(victim).cooldown, 20);
    }

    // ---- "Null joined the game" + its entry in the TAB list ---------------------------------------
    /** Once per server session: the yellow join message, then "Null" appears in everybody's player list. */
    public static void announceJoin(EntityPlayerMP p, boolean force) {
        if (!force && NullTab.isOnline()) return;
        ITextComponent c = new TextComponentTranslation("multiplayer.player.joined", new Object[] { "Null" });
        c.getStyle().setColor(TextFormatting.YELLOW);                             // looks exactly like a real player joining
        MinecraftServer server = p.getServer();
        if (server != null) {
            for (EntityPlayerMP q : server.getPlayerList().getPlayerList()) q.addChatMessage(c);
            NullTab.add(server, (WorldServer) p.worldObj);
        } else {
            p.addChatMessage(c);
        }
    }

    public static void announceLeave(MinecraftServer server, WorldServer w) {
        if (server == null) return;
        ITextComponent c = new TextComponentTranslation("multiplayer.player.left", new Object[] { "Null" });
        c.getStyle().setColor(TextFormatting.YELLOW);
        for (EntityPlayerMP q : server.getPlayerList().getPlayerList()) q.addChatMessage(c);
        NullTab.remove(server, w);
    }

    /** Multiplayer: marks this player as the one it hunts harder for the next 10 minutes. */
    public static void mark(EntityPlayerMP victim) {
        marked = victim.getUniqueID();
        markedLeft = 600;
        NullVoice.broadcast(victim.getServer(), "I am watching " + victim.getName() + " tonight.");
        victim.worldObj.playSound(null, victim.posX, victim.posY, victim.posZ, ModSounds.STING, SoundCategory.HOSTILE, 1.0F, 0.7F);
    }

    /** NEW GAME for one player: story, threat, sealed state, play time, learned behaviour - all back to zero. */
    public static void resetPlayer(EntityPlayerMP p) {
        FinalRitual.cancel(p, null);
        clearNull(p);
        QuestData.resetAll(p);
        PLAYERS.put(p.getUniqueID(), new PlayerHorror());                           // fresh cooldowns, session timer, join message
        PlayerHorror r = rec(p);
        FogController.sendNow(p, r, 0F);
        NetworkHandler.CHANNEL.sendTo(new PacketFx(PacketFx.CHASE_DIST, -1F), p);
        sendStats(p);
        sendOptions(p);
        MinecraftServer s = p.getServer();
        if (s != null && s.getPlayerList().getPlayerList().size() <= 1 && NullTab.isOnline()) announceLeave(s, (WorldServer) p.worldObj);
        if (!GuideBook.has(p)) GuideHandler.give(p);
        msg(p, "A new game begins. Everything starts from zero. It does not remember you... yet.");
    }

    // ---- main loop ------------------------------------------------------------------------
    private void secondTick(EntityPlayerMP p) {
        QuestData.addSeconds(p, 1);
        PlayerHorror r = rec(p);
        r.sessionSeconds++;
        if (p.dimension != 0 || p.isDead) { FogController.send(p, r, 0F); return; }

        QuestManager.tick(p);
        if (p.ticksExisted % 200 == 0) sendStats(p);
        if (p.ticksExisted % 600 == 0) ZoneTracker.sample(p);
        if (r.jumpCd > 0) r.jumpCd--;
        if (r.caveCd > 0) r.caveCd--;
        if (r.torchCd > 0) r.torchCd--;
        if (QuestData.isSealed(p)) { FogController.send(p, r, 0F); return; }

        // one minute after you joined, "Null" joins too
        if (!r.joinMsgSent && QuestData.optJoin(p) && r.sessionSeconds >= ModConfig.joinMessageSeconds) {
            r.joinMsgSent = true;
            announceJoin(p, false);
        }

        WorldServer w = (WorldServer) p.worldObj;
        EntityNull n = findNull(w, r);
        float intensity = intensity(p);
        float pressure = pressure(p);
        boolean night = isNight(w);
        boolean home = isNearHome(p);
        int threat = QuestData.getThreat(p);
        boolean isMarked = p.getUniqueID().equals(marked);

        FogController.second(p, r, n, intensity, night);   // fog from the first second, independent of the monster
        if (n == null && r.nullId != null) {               // it vanished -> cooldown before it can return
            r.nullId = null;
            r.cooldown = Math.max(r.cooldown, nextCooldown(intensity, night, home, threat, pressure));
        }

        // coming out of a cave after a while: it left redstone for you
        if (isUnderground(p)) r.undergroundSeconds++;
        else {
            if (r.undergroundSeconds >= 60 && r.exitCd <= 0 && QuestData.optTrail(p) && w.canSeeSky(new BlockPos(p))) {
                CaveTrail.place(p);
                r.exitCd = 300;
            }
            r.undergroundSeconds = 0;
        }
        if (r.exitCd > 0) r.exitCd--;

        // waking up at night is when it is waiting by your bed
        boolean sleeping = p.isPlayerSleeping();
        if (r.wasSleeping && !sleeping && n == null && QuestData.getStage(p) >= 1 && RAND.nextFloat() < 0.35F
                && QuestData.getSeconds(p) > ModConfig.graceSeconds) {
            run(p, HorrorEvent.BED, false);
            p.worldObj.playSound(null, p.posX, p.posY, p.posZ, ModSounds.STING, SoundCategory.HOSTILE, 0.8F, 0.8F);
        }
        r.wasSleeping = sleeping;

        if (!ModConfig.affectCreative && (p.capabilities.isCreativeMode || p.isSpectator())) return;
        if (FinalRitual.isActive(p)) { FinalRitual.tick(p, n); return; }
        if (n != null) return;
        if (QuestData.getSeconds(p) < ModConfig.graceSeconds) return;

        // cursed signs appear by themselves now and then
        if (--r.signTimer <= 0) {
            r.signTimer = (int) ((300 + RAND.nextInt(300)) / (1F + pressure));
            if (QuestData.optSigns(p) && !SignTrap.hasAny(p) && !isUnderground(p)) SignTrap.place(p);
        }

        // scary sounds drift in on their own at night
        if (night && QuestData.optAmbient(p) && RAND.nextFloat() < 0.004F * (1F + intensity * 2F + threat * 0.1F + pressure)) {
            if (RAND.nextBoolean()) WorldPranks.distantSound(p); else WorldPranks.whisper(p);
        }

        if (r.pending != null) {                           // event waiting behind a fog prelude
            if (--r.pendingDelay <= 0) { HorrorEvent e = r.pending; r.pending = null; run(p, e, false); }
            return;
        }
        if (r.cooldown > 0) { r.cooldown--; return; }

        float timeFactor = Math.min(1F, QuestData.getSeconds(p) / 7200F);
        float prob = ModConfig.eventProbability * LEVEL_MULT[QuestData.optLevel(p)]
                * (1F + timeFactor * 0.8F)                 // the longer you play, the more it comes
                * (1F + pressure * 0.5F)                   // every day and every hour makes it worse
                * (night ? 1.6F : 1F)
                * (home ? 1.3F : 1F)
                * (1F + threat * 0.08F)
                * (isMarked ? 1.7F : (marked != null ? 0.85F : 1F));
        if (RAND.nextFloat() > Math.min(0.97F, prob)) { r.cooldown = 20 + RAND.nextInt(25); return; }

        HorrorEvent ev = pick(p, r, intensity, night, home);
        r.recent.addLast(ev);                                  // organised, not random: remember what just happened
        while (r.recent.size() > 3) r.recent.removeFirst();
        if (BIG.contains(ev)) r.calm = 2; else if (r.calm > 0) r.calm--;
        if (ModConfig.fogEnabled && QuestData.optFog(p) && ev.spawnsNull() && RAND.nextFloat() < ModConfig.fogBeforeEncounterChance) {
            r.pending = ev;                                // fog thickens first, monster 8 s later
            r.pendingDelay = 8;
            r.fogPrelude = 1F;
        } else {
            run(p, ev, false);
        }
        r.cooldown = nextCooldown(intensity, night, home, threat, pressure);
    }

    /** 0..1, grows with play time, quest stage, threat and pressure. */
    public static float intensity(EntityPlayer p) {
        float t = Math.min(1F, QuestData.getSeconds(p) / 7200F);
        return Math.min(1F, 0.1F + QuestData.getStage(p) * 0.18F + t * 0.4F + QuestData.getThreat(p) * 0.05F + pressure(p) * 0.15F);
    }

    private static int nextCooldown(float intensity, boolean night, boolean home, int threat, float pressure) {
        double base = ModConfig.eventIntervalSeconds * (0.6D + RAND.nextDouble() * 0.8D);
        base /= (1.0D + 2.0D * intensity);
        if (night) base /= 1.5D;
        if (home) base /= 1.4D;
        base /= (1.0D + threat * 0.05D);
        base /= (1.0D + pressure * 0.4D);
        return Math.max(12, (int) base + 12);
    }

    private static void add(Map<HorrorEvent, Float> w, HorrorEvent e, float weight) { w.put(e, Float.valueOf(weight)); }
    private static void mul(Map<HorrorEvent, Float> w, HorrorEvent e, float f) {
        Float v = w.get(e);
        if (v != null) w.put(e, Float.valueOf(v.floatValue() * f));
    }

    private static HorrorEvent pick(EntityPlayerMP p, PlayerHorror r, float intensity, boolean night, boolean home) {
        int stage = QuestData.getStage(p);
        if (stage == 0 && QuestData.getSeconds(p) > ModConfig.graceSeconds + 900) return HorrorEvent.CHASE;   // guarantees the first encounter

        Map<HorrorEvent, Float> w = new EnumMap<HorrorEvent, Float>(HorrorEvent.class);
        add(w, HorrorEvent.OBSERVE, 5);
        add(w, HorrorEvent.GLIMPSE, 3);
        add(w, HorrorEvent.FOOTSTEPS, 3);
        add(w, HorrorEvent.SOUND, 3);
        add(w, HorrorEvent.KNOCK, 2);
        add(w, HorrorEvent.WHISPER, 2);
        add(w, HorrorEvent.TORCH, 2);
        add(w, HorrorEvent.DOOR, 2);
        add(w, HorrorEvent.ECHO, 3);
        add(w, HorrorEvent.WINDOW, 3);
        if (QuestData.optDoor(p)) add(w, HorrorEvent.DOORKNOCK, 2);
        if (QuestData.optSigns(p) && !SignTrap.hasAny(p)) add(w, HorrorEvent.SIGN, 2);
        if (isUnderground(p)) {
            add(w, HorrorEvent.CAVE, 6);                       // running steps in the dark
            if (stage >= 1) add(w, HorrorEvent.CAVECHASE, 4);  // and sometimes... it chases you down here
        }
        if (stage >= 1) {
            add(w, HorrorEvent.STALK, 3 + stage);
            add(w, HorrorEvent.BED, 2);
            add(w, HorrorEvent.CHASE, 2 + stage);
            if (QuestData.optChat(p)) add(w, HorrorEvent.MIMIC, 3);
            add(w, HorrorEvent.BLACKOUT, 1);
            if (ModConfig.jumpscareEnabled && QuestData.optJump(p)) add(w, HorrorEvent.JUMPSCARE, 2 + stage / 2);
        } else {
            if (QuestData.optChat(p)) add(w, HorrorEvent.MIMIC, 1);
            if (intensity > 0.3F) add(w, HorrorEvent.STALK, 2);
        }
        if (ModConfig.theftEnabled && QuestData.optTheft(p) && !WorldPranks.chestsNear(p, 80).isEmpty()) {
            add(w, HorrorEvent.THEFT, ZoneTracker.weightHere(p) >= ZoneTracker.HOME_WEIGHT ? 4 : 2);   // more where you live
        }

        if (night) {                                       // sounds, scares and sightings are more common at night
            mul(w, HorrorEvent.FOOTSTEPS, 2F); mul(w, HorrorEvent.SOUND, 2F); mul(w, HorrorEvent.WHISPER, 2F);
            mul(w, HorrorEvent.KNOCK, 2F); mul(w, HorrorEvent.JUMPSCARE, 2F); mul(w, HorrorEvent.OBSERVE, 1.5F);
            mul(w, HorrorEvent.STALK, 1.5F); mul(w, HorrorEvent.SIGN, 1.5F);
            mul(w, HorrorEvent.WINDOW, 2F); mul(w, HorrorEvent.ECHO, 1.5F); mul(w, HorrorEvent.MIMIC, 1.5F);
            mul(w, HorrorEvent.DOORKNOCK, 2F);
        }
        if (home) {                                        // it haunts your bed and your base
            mul(w, HorrorEvent.BED, 3F); mul(w, HorrorEvent.THEFT, 3F); mul(w, HorrorEvent.TORCH, 3F);
            mul(w, HorrorEvent.DOOR, 2.5F); mul(w, HorrorEvent.KNOCK, 2.5F); mul(w, HorrorEvent.FOOTSTEPS, 1.5F);
            mul(w, HorrorEvent.OBSERVE, 1.3F); mul(w, HorrorEvent.WINDOW, 2F); mul(w, HorrorEvent.BLACKOUT, 2.5F);
            mul(w, HorrorEvent.DOORKNOCK, 3F);
            if (!w.containsKey(HorrorEvent.BED)) add(w, HorrorEvent.BED, 3);
        }

        // organised, not random: no repeats of the last three events, and after a BIG event only calm ones follow
        for (HorrorEvent recent : r.recent) mul(w, recent, 0.2F);
        if (r.calm > 0) for (HorrorEvent big : BIG) w.remove(big);

        float total = 0F;
        for (Float v : w.values()) total += v.floatValue();
        float roll = RAND.nextFloat() * Math.max(0.001F, total);
        for (Map.Entry<HorrorEvent, Float> en : w.entrySet()) {
            roll -= en.getValue().floatValue();
            if (roll < 0F) return en.getKey();
        }
        return HorrorEvent.OBSERVE;
    }

    // ---- executing events (also used by /ss) -----------------------------------------------
    /** force = ignore cooldowns and replace any monster already present (used by commands). */
    public static void run(EntityPlayerMP p, HorrorEvent e, boolean force) {
        PlayerHorror r = rec(p);
        float in = intensity(p);
        if (force && (e.spawnsNull() || e == HorrorEvent.JUMPSCARE)) {
            clearNull(p);
            r.pending = null;
        }
        boolean home = isNearHome(p);
        switch (e) {
            case OBSERVE:
                SpawnHelper.spawn(p, r, NullState.OBSERVING, 22, 36, 20 * (25 + RAND.nextInt(30)), false, 0F, true);
                break;
            case GLIMPSE:
                SpawnHelper.spawn(p, r, NullState.OBSERVING, 12, 22, 80, false, 0F, true);
                break;
            case STALK:
                SpawnHelper.spawn(p, r, NullState.STALKING, 24, 34, 20 * 40, false, 0.2F + 0.4F * in, true);
                break;
            case CHASE:
                SpawnHelper.spawn(p, r, NullState.CHASE, 16, 26, 0, false, 0F, false);
                break;
            case BED:
                spawnNearBed(p, r);
                break;
            case CAVECHASE:
                p.worldObj.playSound(null, p.posX, p.posY, p.posZ, ModSounds.HEARTBEAT, SoundCategory.HOSTILE, 1.6F, 0.8F);
                p.worldObj.playSound(null, p.posX, p.posY, p.posZ, ModSounds.WHISPER, SoundCategory.HOSTILE, 1.2F, 0.7F);
                SpawnHelper.spawn(p, r, NullState.CHASE, 14, 22, 0, false, 0F, false);   // underground this uses the tunnels around you
                break;
            case TRAIL:
                CaveTrail.place(p);
                break;
            case JUMPSCARE:
                Jumpscare.trigger(p, r, force);
                break;
            case FOOTSTEPS:
                WorldPranks.footsteps(p);
                break;
            case KNOCK:
                WorldPranks.knock(p);
                break;
            case WHISPER:
                WorldPranks.whisper(p);
                break;
            case SOUND:
                WorldPranks.distantSound(p);
                break;
            case CAVE:
                WorldPranks.caveRun(p);
                break;
            case SIGN:
                SignTrap.place(p);
                break;
            case WINDOW:
                if (!WorldPranks.window(p, r)) {                                   // no window nearby -> it taps on the wall instead
                    WorldPranks.knock(p);
                    p.worldObj.playSound(null, p.posX, p.posY, p.posZ, ModSounds.TAP, SoundCategory.HOSTILE, 1.0F, 0.9F);
                }
                break;
            case DOORKNOCK:
                if (!WorldPranks.doorKnock(p, r)) WorldPranks.knock(p);            // no door nearby -> a knock from nowhere
                break;
            case TORCHSCARE:
                TorchScare.trigger(p, true);
                break;
            case MIMIC:
                WorldPranks.mimic(p);
                break;
            case ECHO:
                WorldPranks.echo(p);
                break;
            case BLACKOUT:
                WorldPranks.blackout(p);
                lurk(p, r);
                break;
            case TORCH:
                WorldPranks.extinguish(p, home ? 5 : 3);
                lurk(p, r);
                break;
            case DOOR:
                WorldPranks.toggleDoor(p);
                lurk(p, r);
                break;
            case THEFT:
                if (!WorldPranks.stealFromChest(p)) WorldPranks.knock(p);          // nothing to take -> it only knocks
                lurk(p, r);
                break;
        }
    }

    /** DISTURBANCE: sometimes it stands in the distance while it interferes with the world. */
    private static void lurk(EntityPlayerMP p, PlayerHorror r) {
        if (RAND.nextFloat() < 0.5F) SpawnHelper.spawn(p, r, NullState.DISTURBANCE, 14, 22, 200, false, 0F, true);
    }

    private static void spawnNearBed(EntityPlayerMP p, PlayerHorror r) {
        WorldServer w = (WorldServer) p.worldObj;
        BlockPos bed = p.getBedLocation();
        BlockPos pos = null;
        if (bed != null && bed.distanceSq(p.posX, p.posY, p.posZ) < 64 * 64) pos = SpawnHelper.standingSpotAround(w, bed, 4, 7, null);
        if (pos == null || findNull(w, r) != null) {
            SpawnHelper.spawn(p, r, NullState.OBSERVING, 14, 22, 120, false, 0F, true);
            return;
        }
        SpawnHelper.spawnAt(p, r, pos, NullState.OBSERVING, 120, false, 0F);
    }

    // ---- monster bookkeeping ---------------------------------------------------------------
    public static EntityNull findNull(WorldServer w, PlayerHorror r) {
        if (r.nullId == null) return null;
        Entity e = w.getEntityFromUuid(r.nullId);
        return (e instanceof EntityNull && !e.isDead) ? (EntityNull) e : null;
    }

    /** Removes the player's monster instantly (no vanish effect). */
    public static void clearNull(EntityPlayerMP p) {
        PlayerHorror r = rec(p);
        EntityNull n = findNull((WorldServer) p.worldObj, r);
        if (n != null) n.setDead();
        r.nullId = null;
    }
}
