package com.spoiledseed.horror;

import com.spoiledseed.registry.ModBlocks;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.WorldServer;

/**
 * Black "Null Blocks" built by The Null when you hide up high. They are wrapped in a PURE BLACK halo (the same one
 * the monster wears: swirling black particles over every face and edge, black smoke rising from the top), can be
 * broken with a pickaxe to keep them, and dissolve after 8 minutes.
 */
public class NullBlocks {
    private static class Rec { WorldServer w; BlockPos pos; int ticks; }
    private static final List<Rec> LIST = new ArrayList<Rec>();
    private static final Random RAND = new Random();
    private static final int LIFETIME = 8 * 60 * 20;

    public static void place(WorldServer w, BlockPos pos) {
        w.setBlockState(pos, ModBlocks.nullBlock.getDefaultState());
        Rec r = new Rec();
        r.w = w; r.pos = pos; r.ticks = LIFETIME;
        LIST.add(r);
        w.playSound(null, pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D, SoundEvents.BLOCK_STONE_PLACE, SoundCategory.HOSTILE, 1.0F, 0.6F);
        for (int i = 0; i < 18; i++) puff(w, pos.getX() + RAND.nextDouble(), pos.getY() + RAND.nextDouble(), pos.getZ() + RAND.nextDouble());
    }

    /** SPELL_MOB takes its colour from the three offset values; with count 0 and (0,0,0) it is a pure black swirl. */
    private static void puff(WorldServer w, double x, double y, double z) {
        w.spawnParticle(EnumParticleTypes.SPELL_MOB, x, y, z, 0, 0.0D, 0.0D, 0.0D, 1.0D);
    }

    /** A random point on the surface of the block (6 faces), slightly outside. */
    private static void surfacePuff(WorldServer w, BlockPos p) {
        double a = RAND.nextDouble(), b = RAND.nextDouble();
        double x = p.getX(), y = p.getY(), z = p.getZ();
        switch (RAND.nextInt(6)) {
            case 0: puff(w, x + a, y - 0.05D, z + b); break;
            case 1: puff(w, x + a, y + 1.05D, z + b); break;
            case 2: puff(w, x - 0.05D, y + a, z + b); break;
            case 3: puff(w, x + 1.05D, y + a, z + b); break;
            case 4: puff(w, x + a, y + b, z - 0.05D); break;
            default: puff(w, x + a, y + b, z + 1.05D); break;
        }
    }

    /** Called every server tick; the halo is refreshed every 4 ticks. */
    public static void tick(int counter) {
        if (LIST.isEmpty() || counter % 4 != 0) return;
        for (Iterator<Rec> it = LIST.iterator(); it.hasNext();) {
            Rec r = it.next();
            if (r.w.getBlockState(r.pos).getBlock() != ModBlocks.nullBlock) { it.remove(); continue; }   // broken by the player
            r.ticks -= 4;
            if (r.ticks <= 0) {
                r.w.setBlockToAir(r.pos);
                for (int i = 0; i < 14; i++) puff(r.w, r.pos.getX() + RAND.nextDouble(), r.pos.getY() + RAND.nextDouble(), r.pos.getZ() + RAND.nextDouble());
                it.remove();
                continue;
            }
            for (int i = 0; i < 6; i++) surfacePuff(r.w, r.pos);
            if (counter % 12 == 0) {                                                                       // black smoke rising off the top
                r.w.spawnParticle(EnumParticleTypes.SMOKE_LARGE, r.pos.getX() + 0.5D, r.pos.getY() + 1.1D, r.pos.getZ() + 0.5D, 1, 0.3D, 0.05D, 0.3D, 0.002D);
            }
        }
    }

    public static void clear() { LIST.clear(); }
}
