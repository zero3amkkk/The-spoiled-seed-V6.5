package com.spoiledseed.horror;

import com.mojang.authlib.GameProfile;
import java.util.UUID;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.network.play.server.SPacketPlayerListItem;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.management.PlayerInteractionManager;
import net.minecraft.world.WorldServer;

/**
 * A fake online player called "Null". It is only a TAB-list entry (it is never added to the world): after the
 * "Null joined the game" message, everybody sees "Null" in the player list, like in any multiplayer server.
 */
public class NullTab {
    private static final UUID ID = UUID.nameUUIDFromBytes("spoiledseed:null-tab-entry".getBytes());
    private static boolean online;
    private static EntityPlayerMP fake;

    public static boolean isOnline() { return online; }

    public static void reset() {
        online = false;
        fake = null;
    }

    private static EntityPlayerMP fake(MinecraftServer server, WorldServer w) {
        if (fake == null) fake = new EntityPlayerMP(server, w, new GameProfile(ID, "Null"), new PlayerInteractionManager(w));
        return fake;
    }

    /** Adds (or re-sends) the entry to every player's tab list. */
    public static void add(MinecraftServer server, WorldServer w) {
        online = true;
        server.getPlayerList().sendPacketToAllPlayers(new SPacketPlayerListItem(SPacketPlayerListItem.Action.ADD_PLAYER, fake(server, w)));
    }

    public static void remove(MinecraftServer server, WorldServer w) {
        if (!online) return;
        online = false;
        server.getPlayerList().sendPacketToAllPlayers(new SPacketPlayerListItem(SPacketPlayerListItem.Action.REMOVE_PLAYER, fake(server, w)));
    }
}
